package danmunoz.inmobile;

import android.app.Application;
import android.util.Log;

import com.littlefluffytoys.littlefluffylocationlibrary.LocationLibrary;

import danmunoz.inmobile.util.imagecache.ImageLoader;

/**
 * Created by Vinicius on 4/13/15.
 */
public class InmobileApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        ImageLoader.getInstance().setup(this);
        // output debug to LogCat, with tag LittleFluffyLocationLibrary
        LocationLibrary.showDebugOutput(true);

        try {
            // in most cases the following initialising code using defaults is probably sufficient:
            //
            // LocationLibrary.initialiseLibrary(getBaseContext(), "com.your.package.name");
            //
            // however for the purposes of the test app, we will request unrealistically frequent location broadcasts
            // every 1 minute, and force a location update if there hasn't been one for 2 minutes.
            LocationLibrary.initialiseLibrary(getBaseContext(), 60 * 1000, 2 * 60 * 1000, "danmunoz.inmobile");
        }
        catch (UnsupportedOperationException ex) {
            Log.w("Inmobile", "UnsupportedOperationException thrown - the device doesn't have any location providers");
        }
    }
}
