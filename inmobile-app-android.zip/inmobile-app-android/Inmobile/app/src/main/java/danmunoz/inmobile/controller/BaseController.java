package danmunoz.inmobile.controller;

import android.content.Context;

import com.j256.ormlite.android.apptools.OpenHelperManager;

import danmunoz.inmobile.persistence.DataBaseHelper;
import danmunoz.inmobile.util.NetworkHelper;

/**
 * Created by Vinicius on 4/12/15.
 */
public class BaseController {
    // Application context
    protected Context context;
    // DataBase Helper
    private DataBaseHelper dataBaseHelper;

    /**
     * Constructor
     * @param context Application context
     */
    protected BaseController(Context context){
        setContext(context);
    }

    protected void setContext(Context context) {
        this.context = context;
    }

    protected Context getContext() {
        return context;
    }

    /**
     * Getter of the database helper
     * @return
     */
    protected DataBaseHelper getHelper() {
        if (this.dataBaseHelper == null) {
            this.dataBaseHelper = OpenHelperManager.getHelper(this.context, DataBaseHelper.class);
        }
        return this.dataBaseHelper;
    }

    /**
     * Method to verify internet connection
     * @return
     */
    protected boolean hasNetworkConnection(){
        return NetworkHelper.hasNetworkConnection(getContext());
    }

}
