package danmunoz.inmobile.controller;

import android.content.Context;
import android.os.AsyncTask;

import com.j256.ormlite.android.apptools.OpenHelperManager;

import org.springframework.web.client.HttpClientErrorException;

import java.sql.SQLException;

import danmunoz.inmobile.controller.listener.ContactListener;
import danmunoz.inmobile.model.Contact;
import danmunoz.inmobile.model.Estate;
import danmunoz.inmobile.network.WrappedError;
import danmunoz.inmobile.network.contact.ContactRequest;
import danmunoz.inmobile.network.contact.ContactRequestData;
import danmunoz.inmobile.network.contact.ContactRequestResponse;
import danmunoz.inmobile.persistence.DataBaseHelper;

/**
 * Created by Vinicius on 4/18/15.
 */
public class ContactController extends BaseController {

    private ContactListener contactListener;

    /**
     * Constructor
     *
     * @param context Application context
     */
    public ContactController(Context context, ContactListener contactListener) {
        super(context);
        this.contactListener = contactListener;
    }

    public void getContact(String objectId){
        if(hasNetworkConnection()){
            ContactRequestData contactRequestData = new ContactRequestData(objectId);
            GetContactTask getContactTask = new GetContactTask();
            getContactTask.execute(contactRequestData);
        }else{
            contactListener.internetConnectionError();
        }
    }

    public static Contact getLocalContactById(Context context,String id)  {
        DataBaseHelper dataBaseHelper = OpenHelperManager.getHelper(context, DataBaseHelper.class);
        Contact result;
        try {
            result = dataBaseHelper.getContactDao().queryForId(id);
        } catch (SQLException e) {
            e.printStackTrace();
            result = null;
        }
        return result;
    }

    private void onRequestFinish(ContactRequestResponse response){
        if(!response.hasError()){
            Contact contact = response.getContact();
            try {
                if(contact.getPhoto()!=null){
                    getHelper().getPhotoDao().createOrUpdate(contact.getPhoto());
                }
                getHelper().getContactDao().update(contact);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            contactListener.onGetContactComplete(contact);
        }else{
            contactListener.onGetContactFailed();
        }
    }


    public class GetContactTask extends AsyncTask<ContactRequestData, Void, ContactRequestResponse> {

        @Override
        protected ContactRequestResponse doInBackground(ContactRequestData... params) {
            ContactRequestResponse contactRequestResponse = new ContactRequestResponse();
            ContactRequestData contactRequestData = params[0];
            try{
                ContactRequest contactRequest = new ContactRequest(contactRequestData);
                contactRequestResponse = contactRequest.performRequest();
            }catch (HttpClientErrorException httpClientException) {
                contactRequestResponse.setResponseError(new WrappedError(httpClientException.getStatusCode().value(), httpClientException));
            }catch (Exception e){
                contactRequestResponse.setResponseError(new WrappedError(e));
            }
            return contactRequestResponse;
        }

        @Override
        protected void onPostExecute(ContactRequestResponse response) {
            super.onPostExecute(response);
            onRequestFinish(response);
        }
    }
}
