package danmunoz.inmobile.controller;

import android.content.Context;
import android.os.AsyncTask;

import com.j256.ormlite.android.apptools.OpenHelperManager;
import com.j256.ormlite.stmt.QueryBuilder;
import com.j256.ormlite.stmt.Where;

import org.springframework.web.client.HttpClientErrorException;

import java.sql.SQLException;
import java.util.List;

import danmunoz.inmobile.controller.listener.EstateListener;
import danmunoz.inmobile.model.Estate;
import danmunoz.inmobile.model.Photo;
import danmunoz.inmobile.network.WrappedError;
import danmunoz.inmobile.network.estate.EstateListRequest;
import danmunoz.inmobile.network.estate.EstateListRequestData;
import danmunoz.inmobile.network.estate.EstateListRequestResponse;
import danmunoz.inmobile.persistence.DataBaseHelper;

/**
 * Created by Vinicius on 4/12/15.
 */
public class EstateController extends BaseController {

    private EstateListener estateListener;

    /**
     * Constructor
     *
     * @param context Application context
     */
    public EstateController(Context context, EstateListener estateListener) {
        super(context);
        this.estateListener = estateListener;
    }

    public void getEstateList(String json,float latitude,float longitude,boolean map){
        this.getEstateList(json, latitude, longitude, map, 0);
    }

    public void getEstateList(String json,double latitude,double longitude,boolean map){
        this.getEstateList(json, latitude, longitude, map, 0);
    }

    public void getEstateList(String json,double latitude,double longitude,boolean map, int skip){
        EstateListRequestData estateListRequestData = new EstateListRequestData();
        estateListRequestData.setJson(json);
        estateListRequestData.setLatitude(latitude);
        estateListRequestData.setLongitude(longitude);
        estateListRequestData.setSkip(skip);
        estateListRequestData.setMap(map);
        GetEstateListTask getEstateListTask = new GetEstateListTask();
        getEstateListTask.execute(estateListRequestData);
    }



    public void onRequestFinish(EstateListRequestResponse response){
        if(!response.hasError()){
            List<Estate> estateList = response.getEstateList();
            for (Estate estate:estateList){
                try {
                    if(estate.getComplexEstate()!=null){
                        getHelper().getComplexEstateDao().createOrUpdate(estate.getComplexEstate());
                    }
                    getHelper().getThumbnailDao().createOrUpdate(estate.getThumbnail());
                    getHelper().getContactDao().createOrUpdate(estate.getContact());
                    Photo[] photos = estate.getPhotos();
                    for(int i=0;i<photos.length;i++){
                        photos[i].setEstateId(estate.getObjectId());
                        getHelper().getPhotoDao().createOrUpdate(photos[i]);
                    }
                    Estate estateBU = getLocalEstateById(context,estate.getObjectId());
                    if(estateBU!=null && estateBU.getFavorite()){
                            estate.setFavorite(true);
                    }else{
                        estate.setFavorite(false);
                    }
                    getHelper().getEstateDao().createOrUpdate(estate);

                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if(response.isSkip()){
                System.out.println("Skip");
                estateListener.onGetEstateListCompleteSkipped(estateList);
            }else {
                System.out.println("Normal");
                estateListener.onGetEstateListComplete(estateList);
            }
        }else{
            estateListener.onGetEstateListFailed();
        }
    }



    public static void updateEstate(Context context,Estate estate){
        DataBaseHelper dataBaseHelper = OpenHelperManager.getHelper(context, DataBaseHelper.class);
        try {
            dataBaseHelper.getEstateDao().update(estate);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static Estate getLocalEstateById(Context context,String id)  {
        DataBaseHelper dataBaseHelper = OpenHelperManager.getHelper(context, DataBaseHelper.class);
        Estate  result;
        try {
            result = dataBaseHelper.getEstateDao().queryForId(id);
        } catch (SQLException e) {
            e.printStackTrace();
            result = null;
        }
        return result;
    }

    public static List<Photo> getLocalPhotosEstateById(Context context,String id)  {
        try{
        DataBaseHelper dataBaseHelper = OpenHelperManager.getHelper(context, DataBaseHelper.class);
        QueryBuilder<Photo, String> builder = dataBaseHelper.getPhotoDao().queryBuilder();
        Where<Photo,String> where = builder.where();
        where.eq("estateId", id);
        List<Photo> photoList = builder.query();
        if(!photoList.isEmpty() && photoList!=null) {
            return photoList;
        }
     } catch (SQLException e) {
        e.printStackTrace();
        }
        return null;
    }

    public void getFavoriteList() {
        try {
            QueryBuilder<Estate, String> builder = getHelper().getEstateDao().queryBuilder();
            Where<Estate,String> where = builder.where();
            where.eq(Estate.FAVORITE_TAG, true);
            List<Estate> estateList = builder.query();
            if(!estateList.isEmpty() && estateList!=null) {
                estateListener.onGetEstateListComplete(estateList);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public class GetEstateListTask extends AsyncTask<EstateListRequestData, Void, EstateListRequestResponse> {

        @Override
        protected EstateListRequestResponse doInBackground(EstateListRequestData... params) {
            EstateListRequestResponse estateListRequestResponse = new EstateListRequestResponse();
            EstateListRequestData estateListRequestData = params[0];
            try{
                EstateListRequest getReportListRequest = new EstateListRequest(estateListRequestData);
                estateListRequestResponse = getReportListRequest.performRequest();
                estateListRequestResponse.setSkip(params[0].getSkip()>0?true:false);
            }catch (HttpClientErrorException httpClientException) {
                estateListRequestResponse.setResponseError(new WrappedError(httpClientException.getStatusCode().value(), httpClientException));
            }catch (Exception e){
                estateListRequestResponse.setResponseError(new WrappedError(e));
            }
            return estateListRequestResponse;
        }

        @Override
        protected void onPostExecute(EstateListRequestResponse response) {
            super.onPostExecute(response);
            onRequestFinish(response);
        }
    }
}
