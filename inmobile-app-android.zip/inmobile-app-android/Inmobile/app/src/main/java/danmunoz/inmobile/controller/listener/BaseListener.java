package danmunoz.inmobile.controller.listener;

/**
 * Created by Vinicius on 4/13/15.
 */
public interface BaseListener {
    void internetConnectionError();
}
