package danmunoz.inmobile.controller.listener;

import danmunoz.inmobile.model.Contact;

/**
 * Created by Vinicius on 4/18/15.
 */
public interface ContactListener extends BaseListener{
    void onGetContactComplete(Contact contact);
    void onGetContactFailed();
}
