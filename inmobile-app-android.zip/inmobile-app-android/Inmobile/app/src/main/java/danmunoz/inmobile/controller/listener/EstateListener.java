package danmunoz.inmobile.controller.listener;

import java.util.List;

import danmunoz.inmobile.model.Estate;

/**
 * Created by Vinicius on 4/13/15.
 */
public interface EstateListener extends BaseListener{
    void onGetEstateListComplete(List<Estate> estateList);
    void onGetEstateListCompleteSkipped(List<Estate> estateList);
    void onGetEstateListFailed();
}
