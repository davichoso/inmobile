package danmunoz.inmobile.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.j256.ormlite.field.DatabaseField;

/**
 * Created by Vinicius on 4/17/15.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ComplexEstate {

    @DatabaseField(id = true,columnName = "objectId")
    @JsonProperty
    private String objectId;

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    public String getObjectId() {
        return objectId;
    }
}
