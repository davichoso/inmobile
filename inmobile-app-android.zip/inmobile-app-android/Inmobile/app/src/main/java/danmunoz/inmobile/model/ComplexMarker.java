package danmunoz.inmobile.model;

import com.google.android.gms.maps.model.Marker;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Vinicius on 4/20/15.
 */
public class ComplexMarker {

    private List<Estate> estateList;

    private String complexId;

    public Marker marker;

    public ComplexMarker(String complexId){
        this.complexId = complexId;
        this.estateList = new ArrayList<>();
    }

    public void setComplexId(String complexId) {
        this.complexId = complexId;
    }

    public void addEstate(Estate estate) {
        this.estateList.add(estate);
    }

    public void setMarker(Marker marker) {
        this.marker = marker;
    }

    public List<Estate> getEstateList() {
        return estateList;
    }

    public Marker getMarker() {
        return marker;
    }

    public String getComplexId() {
        return complexId;
    }
}
