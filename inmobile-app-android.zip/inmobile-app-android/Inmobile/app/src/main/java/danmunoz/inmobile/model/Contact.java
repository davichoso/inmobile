package danmunoz.inmobile.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.j256.ormlite.field.DatabaseField;

/**
 * Created by Vinicius on 4/12/15.
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class Contact {

    @DatabaseField(id = true)
    @JsonProperty
    private String objectId;

    @DatabaseField
    @JsonProperty
    private String firstName;

    @DatabaseField
    @JsonProperty
    private String lastName;

    @DatabaseField
    @JsonProperty
    private String email;

    @DatabaseField
    @JsonProperty
    private Integer mobile;

    @DatabaseField(foreign = true,foreignAutoCreate = true,foreignAutoRefresh = true)
    @JsonProperty
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private Photo photo;

    public void setEmail(String email) {
        this.email = email;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setMobile(Integer mobile) {
        this.mobile = mobile;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    public String getObjectId() {
        return objectId;
    }

    public Integer getMobile() {
        return mobile;
    }

    public String getEmail() {
        return email;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setPhoto(Photo photo) {
        this.photo = photo;
    }

    public Photo getPhoto() {
        return photo;
    }
}
