package danmunoz.inmobile.model;

import android.graphics.drawable.Drawable;

/**
 * Created by Vinicius on 4/11/15.
 */
public class DrawerItem {
    private Drawable drawableIcon;
    private String title;

    public DrawerItem(String title, Drawable drawableIcon){
        this.title = title;
        this.drawableIcon = drawableIcon;
    }

    public void setDrawableIcon(Drawable drawableIcon) {
        this.drawableIcon = drawableIcon;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Drawable getDrawableIcon() {
        return drawableIcon;
    }

    public String getTitle() {
        return title;
    }
}
