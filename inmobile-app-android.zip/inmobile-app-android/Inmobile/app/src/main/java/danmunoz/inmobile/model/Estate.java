package danmunoz.inmobile.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.android.gms.maps.model.Marker;
import com.j256.ormlite.field.DatabaseField;

/**
 * Created by Vinicius on 4/12/15.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Estate {

    final public static String FAVORITE_TAG = "favorite";

    public static final int TYPE_CASA = 0;
    public static final int TYPE_DEPTO = 1;
    public static final int TYPE_LOTE = 2;
    public static final int TYPE_LOCAL = 3;
    public static final int TYPE_OFICINA = 4;
    public static final int TYPE_HOTEL = 5;

    public static final int TYPE_CONTRACT_VENTA = 0;
    public static final int TYPE_CONTRACT_RENTA = 1;
    public static final int TYPE_CONTRACT_ALQUILER = 2;

    @DatabaseField(id = true,columnName = "objectId")
    @JsonProperty
    private String objectId;

    @DatabaseField(columnName = "address1")
    @JsonProperty
    private String address1;

    @DatabaseField(columnName = "address2")
    @JsonProperty
    private String address2;

    @DatabaseField(columnName = "bathrooms")
    @JsonProperty
    private Integer bathrooms;

    @DatabaseField(columnName = "bbq")
    @JsonProperty
    private Boolean bbq;

    @DatabaseField(columnName = "bedrooms")
    @JsonProperty
    private Integer bedrooms;

    @DatabaseField(columnName = "builtSurface")
    @JsonProperty
    private Integer builtSurface;

    @DatabaseField(columnName = "city")
    @JsonProperty
    private String city;

    @DatabaseField(columnName = "country")
    @JsonProperty
    private String country;

    @DatabaseField(columnName = "estateDescription")
    @JsonProperty
    private String estateDescription;

    @DatabaseField(columnName = "isPublished")
    @JsonProperty
    private Boolean isPublished;

    @DatabaseField(columnName = "latitude")
    @JsonProperty
    private Double latitude;

    @DatabaseField(columnName = "longitude")
    @JsonProperty
    private Double longitude;

    @DatabaseField(columnName = "parckingSpace")
    @JsonProperty
    private Integer parkingSpace;

    @DatabaseField(columnName = "pets")
    @JsonProperty
    private Boolean pets;

    @DatabaseField(columnName = "pool")
    @JsonProperty
    private Boolean pool;

    @DatabaseField(columnName = "price")
    @JsonProperty
    private Integer price;

    @DatabaseField(columnName = "title")
    @JsonProperty
    private String title;
    
    @DatabaseField(columnName = "surface")
    @JsonProperty
    private int surface;

    @DatabaseField(columnName = "type")
    @JsonProperty
    private Integer type;

    @DatabaseField(columnName = "contractType")
    @JsonProperty
    private Integer contractType;

    @DatabaseField(columnName = "currency")
    @JsonProperty
    private int currency;

    @DatabaseField(foreign = true,foreignAutoCreate = true,foreignAutoRefresh = true)
    @JsonProperty("contactPerson")
    private Contact contact;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    @DatabaseField(foreign = true,foreignAutoCreate = true,foreignAutoRefresh = true)
    @JsonProperty
    private Thumbnail thumbnail;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    @JsonProperty
    private Photo[] photos;

    public Marker marker;

    @DatabaseField(columnName = FAVORITE_TAG)
    private Boolean favorite;

    @DatabaseField
    //@JsonProperty
    private String createdAt;

    @JsonProperty
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    @DatabaseField(foreign = true,foreignAutoCreate = true,foreignAutoRefresh = true)
    private ComplexEstate complexEstate;

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public void setBathrooms(Integer bathrooms) {
        this.bathrooms = bathrooms;
    }

    public void setBbq(Boolean bbq) {
        this.bbq = bbq;
    }

    public void setBedrooms(Integer bedrooms) {
        this.bedrooms = bedrooms;
    }

    public void setBuiltSurface(Integer builtSurface) {
        this.builtSurface = builtSurface;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public void setEstateDescription(String estateDescription) {
        this.estateDescription = estateDescription;
    }

    public void setIsPublished(Boolean isPublished) {
        this.isPublished = isPublished;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    public void setParkingSpace(Integer parkingSpace) {
        this.parkingSpace = parkingSpace;
    }

    public void setPets(Boolean pets) {
        this.pets = pets;
    }

    public void setPool(Boolean pool) {
        this.pool = pool;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getBathrooms() {
        return bathrooms;
    }

    public Integer getBedrooms() {
        return bedrooms;
    }

    public Integer getBuiltSurface() {
        return builtSurface;
    }

    public Integer getParkingSpace() {
        return parkingSpace;
    }

    public Integer getPrice() {
        return price;
    }

    public String getAddress1() {
        return address1;
    }

    public String getAddress2() {
        return address2;
    }

    public String getCity() {
        return city;
    }

    public String getCountry() {
        return country;
    }

    public String getEstateDescription() {
        return estateDescription;
    }

    public Double getLatitude() {
        return latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public String getObjectId() {
        return objectId;
    }

    public String getTitle() {
        return title;
    }

    public Integer getType() {
        return type;
    }

    public Contact getContact() {
        return contact;
    }

    public void setContact(Contact contact) {
        this.contact = contact;
    }

    public void setThumbnail(Thumbnail thumbnail) {
        this.thumbnail = thumbnail;
    }

    public Thumbnail getThumbnail() {
        return thumbnail;
    }

    public void setFavorite(Boolean favorite) {
        this.favorite = favorite;
    }

    public Boolean getFavorite() {
        return favorite;
    }

    public void setPhotos(Photo[] photos) {
        this.photos = photos;
    }

    public Photo[] getPhotos() {
        return photos;
    }

    public void setCurrency(int currency) {
        this.currency = currency;
    }

    public int getCurrency() {
        return currency;
    }

    public void setSurface(int surface) {
        this.surface = surface;
    }

    public int getSurface() {
        return surface;
    }

    public void setComplexEstate(ComplexEstate complexEstate) {
        this.complexEstate = complexEstate;
    }

    public ComplexEstate getComplexEstate() {
        return complexEstate;
    }

    public void setContractType(Integer contractType) {
        this.contractType = contractType;
    }

    public Integer getContractType() {
        return contractType;
    }


    public Boolean getPets() {
        return pets;
    }

    public Boolean getPool() {
        return pool;
    }

    public Boolean getBbq() {
        return bbq;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedAt() {
        return createdAt;
    }
}
