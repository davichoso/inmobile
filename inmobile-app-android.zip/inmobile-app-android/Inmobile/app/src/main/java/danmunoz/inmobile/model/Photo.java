package danmunoz.inmobile.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.j256.ormlite.field.DatabaseField;

/**
 * Created by Vinicius on 4/12/15.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Photo {

    /*@DatabaseField(generatedId = true, allowGeneratedIdInsert=true)
    private Integer id;*/

    @DatabaseField
    private String estateId;

    @JsonProperty
    private String __type;

    @DatabaseField(id = true)
    @JsonProperty
    private String name;

    @DatabaseField
    @JsonProperty
    private String url;

    public void setEstateId(String estateId) {
        this.estateId = estateId;
    }

    public String getEstateId() {
        return estateId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void set__type(String __type) {
        this.__type = __type;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getName() {
        return name;
    }

    public String get__type() {
        return __type;
    }

    public String getUrl() {
        return url;
    }

    /*public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }*/
}
