package danmunoz.inmobile.model;

/**
 * Created by Vinicius on 5/10/15.
 */
public class Type {

    public static final int TYPE_CASA = 0;
    public static final int TYPE_DEPTO = 1;
    public static final int TYPE_LOTE = 2;
    public static final int TYPE_LOCAL = 3;
    public static final int TYPE_OFICINA = 4;
    public static final int TYPE_HOTEL = 5;

    public static final int TYPE_CONTRACT_VENTA = 0;
    public static final int TYPE_CONTRACT_RENTA = 1;
    public static final int TYPE_CONTRACT_ALQUILER = 2;


}
