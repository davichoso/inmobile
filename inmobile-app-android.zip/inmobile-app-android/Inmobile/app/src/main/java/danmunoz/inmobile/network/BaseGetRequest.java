package danmunoz.inmobile.network;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.InterceptingClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Vinicius on 4/12/15.
 */
public abstract class BaseGetRequest<T> extends BaseRequest<T> {

        /**
         * Gets the Response class
         * @return the Response class
         */
        public abstract Class<T> getResponseClass();

        @Override
        public T performRequest() {
            HttpEntity<T> requestEntity = new HttpEntity<T>(getHeaders());
            RestTemplate restTemplate = getRestTemplate();
            ClientHttpRequestInterceptor ri = new LoggingRequestInterceptor();
            List<ClientHttpRequestInterceptor> ris = new ArrayList<>();
            ris.add(ri);
            restTemplate.setInterceptors(ris);
            restTemplate.setRequestFactory(new InterceptingClientHttpRequestFactory(
                    new BufferingClientHttpRequestFactory(new SimpleClientHttpRequestFactory()), ris));

          /*  String query = "{\"bathrooms\":5}";
            String url = Links.getEstateLink()+"?where={query}";*/

            //ResponseEntity<T> requestResult = restTemplate.exchange(url,HttpMethod.GET, requestEntity, getResponseClass(),query);

            ResponseEntity<T> requestResult = restTemplate.exchange(getUrl(),HttpMethod.GET, requestEntity, getResponseClass());
            T result = requestResult.getBody();
            return result;
        }
    }

