package danmunoz.inmobile.network;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Vinicius on 4/12/15.
 */
public abstract class BaseRequest<T> {

    /**
     * Gets the url used for the request
     * @return the url that will be used in the request.
     */
    public abstract String getUrl();

    /**
     * Returns the HttpHeaders to be used in the request.
     * @return
     */
    public HttpHeaders getHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Accept","application/json");
        headers.add("X-Parse-Application-Id","yqhMxjshzjBw5II3RrxtRzH6xcZOIRnxCNDxhLjT");
        headers.add("X-Parse-REST-API-Key","g3fsTN4Ua3M24knE8nLEoM5n7c80CXcrmMTbOqJl");
        final List<MediaType> acceptableMediaTypes = new ArrayList<>();
        //acceptableMediaTypes.add(new MediaType("text", "plain", Charset.forName("UTF-8")));
        acceptableMediaTypes.add(new MediaType("application", "x-www-form-urlencoded"));
        headers.setAccept(acceptableMediaTypes);

        return headers;
    }

    /**
     * Method that creates the restTemplate instance
     * @return a restTemplate instance to be used for the request.
     */
    public RestTemplate getRestTemplate() {
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
        return restTemplate;
    }

    /**
     * Method that performs the requests
     * @return The Object obtained after performing the Request
     */
    public abstract T performRequest();

}
