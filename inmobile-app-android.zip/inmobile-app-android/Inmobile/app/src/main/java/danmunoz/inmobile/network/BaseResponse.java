package danmunoz.inmobile.network;

import org.springframework.http.HttpStatus;

/**
 * Created by Vinicius on 4/12/15.
 */
public class BaseResponse {
    private WrappedError responseError;
    private HttpStatus httpStatus;

    /**
     * Gets if the response has an error
     *
     */
    public boolean hasError() {
        return responseError != null;
    }

    /**
     * Gets an error returned in the response
     *
     */
    public WrappedError getResponseError() {
        return responseError;
    }

    /**
     * Sets an error returned in the response
     * @param responseError
     */
    public void setResponseError(WrappedError responseError) {
        this.responseError = responseError;
    }

    public void setHttpStatus(HttpStatus httpStatus) {
        this.httpStatus = httpStatus;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }
}
