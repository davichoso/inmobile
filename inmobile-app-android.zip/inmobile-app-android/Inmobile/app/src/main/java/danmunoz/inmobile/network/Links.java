package danmunoz.inmobile.network;

/**
 * Created by Vinicius on 4/12/15.
 */
public class Links {
    private static final String apiHostUrl = "https://parseapi.back4app.com/classes/";

    public static String getEstateLink(){
        return  apiHostUrl + "Estate";
    }

    public static String getUserLink(String objectId){
        return apiHostUrl+"Person/"+objectId;
    }
}
