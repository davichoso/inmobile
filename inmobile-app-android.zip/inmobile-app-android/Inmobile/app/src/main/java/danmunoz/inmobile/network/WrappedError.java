package danmunoz.inmobile.network;

/**
 * Created by Vinicius on 4/12/15.
 */
public class WrappedError {
    public int getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }

    public Throwable getThrowable() {
        return throwable;
    }

    public void setThrowable(Throwable throwable) {
        this.throwable = throwable;
    }

    int errorCode;
    Throwable throwable;


    public WrappedError(int errorCode) {
        this.errorCode = errorCode;
    }
    public WrappedError(Throwable throwable) {
        this.throwable = throwable;
    }

    public WrappedError(int errorCode, Throwable throwable) {
        this.errorCode = errorCode;
        this.throwable = throwable;
    }

    public void throwError() throws Throwable {
        if (throwable != null) {
            throw throwable;
        }
    }
}
