package danmunoz.inmobile.network.contact;

import danmunoz.inmobile.network.BaseGetRequest;
import danmunoz.inmobile.network.Links;

/**
 * Created by Vinicius on 4/18/15.
 */
public class ContactRequest extends BaseGetRequest<ContactRequestResponse> {

    private ContactRequestData contactRequestData;

    public ContactRequest(ContactRequestData contactRequestData){
        this.contactRequestData = contactRequestData;
    }

    @Override
    public Class<ContactRequestResponse> getResponseClass() {
        return ContactRequestResponse.class;
    }

    @Override
    public String getUrl() {
        return Links.getUserLink(contactRequestData.getContactId());
    }
}
