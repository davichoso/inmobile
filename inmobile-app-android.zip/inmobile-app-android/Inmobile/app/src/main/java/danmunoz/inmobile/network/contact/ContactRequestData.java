package danmunoz.inmobile.network.contact;

/**
 * Created by Vinicius on 4/18/15.
 */
public class ContactRequestData {

    private String contactId;

    public ContactRequestData(String contactId){
        this.contactId = contactId;
    }


    public String getContactId() {
        return contactId;
    }
}
