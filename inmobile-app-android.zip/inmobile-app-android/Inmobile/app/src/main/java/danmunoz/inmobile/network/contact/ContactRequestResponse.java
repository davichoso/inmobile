package danmunoz.inmobile.network.contact;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import danmunoz.inmobile.model.Contact;
import danmunoz.inmobile.network.BaseResponse;
import danmunoz.inmobile.network.deserializer.ContactDeserializer;

/**
 * Created by Vinicius on 4/18/15.
 */
@JsonDeserialize(using = ContactDeserializer.class)
public class ContactRequestResponse extends BaseResponse{

        private Contact contact;

    public void setContact(Contact contact) {
        this.contact = contact;
    }

    public Contact getContact() {
        return contact;
    }
}
