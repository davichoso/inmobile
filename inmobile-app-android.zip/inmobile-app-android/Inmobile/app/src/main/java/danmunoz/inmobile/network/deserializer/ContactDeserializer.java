package danmunoz.inmobile.network.deserializer;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.util.ArrayList;

import danmunoz.inmobile.model.Contact;
import danmunoz.inmobile.model.Estate;
import danmunoz.inmobile.network.WrappedError;
import danmunoz.inmobile.network.contact.ContactRequestResponse;
import danmunoz.inmobile.network.estate.EstateListRequestResponse;

/**
 * Created by Vinicius on 4/18/15.
 */
public class ContactDeserializer extends com.fasterxml.jackson.databind.JsonDeserializer<ContactRequestResponse> {
    @Override
    public ContactRequestResponse deserialize(JsonParser jsonParser,
                                                 DeserializationContext deserializationContext) throws IOException {
        ObjectCodec oc = jsonParser.getCodec();
        JsonNode node = oc.readTree(jsonParser);

        ContactRequestResponse responseData = new ContactRequestResponse();
        if (node.has("objectId")) {
            Contact contact = new ObjectMapper().readValue(node.toString(), new TypeReference<Contact>() {
            });
            responseData.setContact(contact);
        } else {
            responseData.setResponseError(new WrappedError(new Exception("Error while deserializing response result")));
        }
        return responseData;
    }
}