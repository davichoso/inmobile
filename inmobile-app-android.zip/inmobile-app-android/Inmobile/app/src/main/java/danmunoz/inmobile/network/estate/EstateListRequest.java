package danmunoz.inmobile.network.estate;

import com.littlefluffytoys.littlefluffylocationlibrary.LocationInfo;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.InterceptingClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;
import org.springframework.web.util.UriUtils;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import danmunoz.inmobile.network.BaseGetRequest;
import danmunoz.inmobile.network.Links;
import danmunoz.inmobile.network.LoggingRequestInterceptor;

/**
 * Created by Vinicius on 4/12/15.
 */
public class EstateListRequest extends BaseGetRequest<EstateListRequestResponse> {

    private EstateListRequestData estateListRequestData;

    public EstateListRequest(EstateListRequestData estateListRequestData) {
        this.estateListRequestData = estateListRequestData;
    }

    @Override
    public Class<EstateListRequestResponse> getResponseClass() {
        return EstateListRequestResponse.class;
    }

    @Override
    public String getUrl() {
        return Links.getEstateLink();
    }

    @Override
    public EstateListRequestResponse performRequest() {
        HttpEntity<EstateListRequestResponse> requestEntity = new HttpEntity<EstateListRequestResponse>(getHeaders());
        RestTemplate restTemplate = getRestTemplate();
        ClientHttpRequestInterceptor ri = new LoggingRequestInterceptor();
        List<ClientHttpRequestInterceptor> ris = new ArrayList<>();
        ris.add(ri);
        restTemplate.setInterceptors(ris);
        restTemplate.setRequestFactory(new InterceptingClientHttpRequestFactory(
                new BufferingClientHttpRequestFactory(new SimpleClientHttpRequestFactory()), ris));
        ResponseEntity<EstateListRequestResponse> requestResult;
        String url = Links.getEstateLink() + "?where={query}&limit=10";
        if(estateListRequestData.getSkip()>0){
            url += "&skip="+estateListRequestData.getSkip();
        }
        if(estateListRequestData.getJson()!=null){
            requestResult = restTemplate.exchange(url,HttpMethod.GET, requestEntity, getResponseClass(),"{"+estateListRequestData.getJson()+"}");
        }else{
            if(estateListRequestData.isMap()){
                String query ="{\"coordinate\":{\"$nearSphere\":{\"__type\":\"GeoPoint\",\"longitude\":"+estateListRequestData.getLongitude()+",\"latitude\":"+estateListRequestData.getLatitude()+"}}}";
                requestResult = restTemplate.exchange(url,HttpMethod.GET, requestEntity, getResponseClass(),query);
            }else{
                url = getUrl()+"?limit=10";
                if(estateListRequestData.getSkip()>0){
                    url += "&skip="+estateListRequestData.getSkip();
                }
                requestResult = restTemplate.exchange(url, HttpMethod.GET, requestEntity, getResponseClass());
            }
        }

        EstateListRequestResponse result = requestResult.getBody();
        return result;
    }
}
