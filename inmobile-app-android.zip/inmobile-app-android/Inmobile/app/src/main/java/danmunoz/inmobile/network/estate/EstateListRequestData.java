package danmunoz.inmobile.network.estate;

/**
 * Created by Vinicius on 4/12/15.
 */
public class EstateListRequestData {

    private String json;
    private boolean map;
    private Double latitude;
    private Double longitude;
    private int skip;

    public void setJson(String json) {
        this.json = json;
    }

    public String getJson() {
        return json;
    }

    public void setMap(boolean map) {
        this.map = map;
    }

    public boolean isMap() {
        return map;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setSkip(int skip) {
        this.skip = skip;
    }

    public int getSkip() {
        return skip;
    }
}
