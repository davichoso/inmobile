package danmunoz.inmobile.network.estate;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import java.util.List;

import danmunoz.inmobile.model.Estate;
import danmunoz.inmobile.network.BaseResponse;
import danmunoz.inmobile.network.deserializer.EstateListDeserializer;

/**
 * Created by Vinicius on 4/12/15.
 */
@JsonDeserialize(using = EstateListDeserializer.class)
public class EstateListRequestResponse extends BaseResponse {

    private List<Estate> estateList;
    private boolean skip;

    public void setEstateList(List<Estate> estateList) {
        this.estateList = estateList;
    }

    public List<Estate> getEstateList() {
        return estateList;
    }

    public void setSkip(boolean skip) {
        this.skip = skip;
    }

    public boolean isSkip() {
        return skip;
    }
}
