package danmunoz.inmobile.persistence;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.j256.ormlite.android.apptools.OrmLiteSqliteOpenHelper;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.table.TableUtils;

import java.sql.SQLException;

import danmunoz.inmobile.model.ComplexEstate;
import danmunoz.inmobile.model.Contact;
import danmunoz.inmobile.model.Estate;
import danmunoz.inmobile.model.Photo;
import danmunoz.inmobile.model.Thumbnail;

/**
 * Created by Vinicius on 4/12/15.
 */
public class DataBaseHelper extends OrmLiteSqliteOpenHelper {

    // name of the database file for your application -- change to something appropriate for your app
    private static final String DATABASE_NAME = "Inmobile.db";
    // any time you make changes to your database objects, you may have to increase the database version
    private static final int DATABASE_VERSION = 1;

    // the DAO object we use to access the SimpleData table
    private Dao<Estate, String> estateDao = null;
    private Dao<ComplexEstate, String> complexEstateDao = null;
    private Dao<Contact, String> contactDao = null;
    private Dao<Photo,String> photoDao = null;
    private Dao<Thumbnail,Integer> thumbnailDao = null;

    public DataBaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * This is called when the database is first created. Usually you should call createTable statements here to create
     * the tables that will store your data.
     */
    @Override
    public void onCreate(SQLiteDatabase db, ConnectionSource connectionSource) {
        try {
            Log.i(DataBaseHelper.class.getName(), "onCreate");
            TableUtils.createTableIfNotExists(connectionSource, Estate.class);
            Log.i(DataBaseHelper.class.getName(), "created estate table ");
            TableUtils.createTableIfNotExists(connectionSource, Contact.class);
            Log.i(DataBaseHelper.class.getName(), "created contact table ");
            TableUtils.createTableIfNotExists(connectionSource, Photo.class);
            Log.i(DataBaseHelper.class.getName(), "created photo table ");
            TableUtils.createTableIfNotExists(connectionSource, Thumbnail.class);
            Log.i(DataBaseHelper.class.getName(), "created thumbnail table ");
            TableUtils.createTableIfNotExists(connectionSource, ComplexEstate.class);
            Log.i(DataBaseHelper.class.getName(), "created complex state table ");
        } catch (SQLException e) {
            Log.e(DataBaseHelper.class.getName(), "Can't create database", e);
            throw new RuntimeException(e);
        }
    }

    /**
     * This is called when your application is upgraded and it has a higher version number. This allows you to adjust
     * the various data to match the new version number.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, ConnectionSource connectionSource, int oldVersion, int newVersion) {
        try {
            Log.i(DataBaseHelper.class.getName(), "onUpgrade");
            TableUtils.dropTable(connectionSource, Estate.class, true);
            TableUtils.dropTable(connectionSource, Contact.class, true);
            TableUtils.dropTable(connectionSource, Photo.class, true);
            TableUtils.dropTable(connectionSource, Thumbnail.class, true);
            TableUtils.dropTable(connectionSource, ComplexEstate.class, true);
            // after we drop the old databases, we create the new ones
            onCreate(db, connectionSource);
        } catch (SQLException e) {
            Log.e(DataBaseHelper.class.getName(), "Can't drop databases", e);
            throw new RuntimeException(e);
        }
    }

    public void dropTables(){
        try{
            TableUtils.dropTable(connectionSource, Estate.class, true);
            TableUtils.dropTable(connectionSource, Contact.class, true);
            TableUtils.dropTable(connectionSource, Photo.class, true);
            TableUtils.dropTable(connectionSource, Thumbnail.class, true);
            TableUtils.dropTable(connectionSource, ComplexEstate.class, true);
        } catch (SQLException e) {
            Log.e(DataBaseHelper.class.getName(), "Can't drop databases", e);
            throw new RuntimeException(e);
        }
    }

    /**
     * Returns the Database Access Object (DAO) for our SimpleData class. It will create it or just give the cached
     * value.
     */
    public Dao<Estate, String> getEstateDao() throws SQLException {
        if (estateDao == null) {
            estateDao = getDao(Estate.class);
        }
        return estateDao;
    }

    public Dao<ComplexEstate, String> getComplexEstateDao() throws SQLException {
        if (complexEstateDao == null) {
            complexEstateDao = getDao(ComplexEstate.class);
        }
        return complexEstateDao;
    }

    public Dao<Contact, String> getContactDao() throws SQLException {
        if (contactDao == null) {
            contactDao = getDao(Contact.class);
        }
        return contactDao;
    }

    public Dao<Photo, String> getPhotoDao() throws SQLException {
        if (photoDao == null) {
            photoDao = getDao(Photo.class);
        }
        return photoDao;
    }

    public Dao<Thumbnail, Integer> getThumbnailDao() throws SQLException {
        if (thumbnailDao == null) {
            thumbnailDao = getDao(Thumbnail.class);
        }
        return thumbnailDao;
    }

}
