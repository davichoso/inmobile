package danmunoz.inmobile.persistence;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

/**
 * Created by vinicius on 09-04-14.
 * This class help to manage the shared preferences
 */
public class PreferencesHelper {
    public static final String INTRO = "intro";
    private static String name = "InmobilePreferences";
    public static final String NULL = "null";

    private static Editor getEditor(Context pContext){
        return getPreferences(pContext).edit();
    }

    private static SharedPreferences getPreferences(Context pContext){
        return pContext.getSharedPreferences(name,
                Context.MODE_PRIVATE);
    }

    public static void putBoolean(String pTag, boolean pValue, Context pContext) {
        Editor editor = getEditor(pContext);
        editor.putBoolean(pTag, pValue);
        editor.commit();
    }

    public static boolean getBoolean(String pTag, Context pContext) {
        SharedPreferences sharedPreferences = getPreferences(pContext);
        return sharedPreferences.getBoolean(pTag, false);
    }

    public static void clear(Context pContext){
        Editor editor = getEditor(pContext);
        editor.clear();
        editor.commit();
    }



}
