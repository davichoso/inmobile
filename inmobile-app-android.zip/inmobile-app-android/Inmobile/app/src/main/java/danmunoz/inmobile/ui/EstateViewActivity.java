package danmunoz.inmobile.ui;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import danmunoz.inmobile.R;
import danmunoz.inmobile.controller.ContactController;
import danmunoz.inmobile.controller.EstateController;
import danmunoz.inmobile.controller.listener.ContactListener;
import danmunoz.inmobile.model.Contact;
import danmunoz.inmobile.model.Estate;
import danmunoz.inmobile.model.Photo;
import danmunoz.inmobile.network.deserializer.ContactDeserializer;
import danmunoz.inmobile.ui.adapter.ImageAdapter;
import danmunoz.inmobile.util.DateHelper;
import danmunoz.inmobile.util.TintHelper;
import danmunoz.inmobile.util.imagecache.ImageLoader;

public class EstateViewActivity extends AppCompatActivity implements ContactListener, View.OnClickListener {

    final public static String ID_FLAG = "estateId";
    public static final int FRAGMENT_RESULT = 0;
    private MenuItem favoriteButton;
    private Estate estate;
    private ContactController contactController;

    //Views
    private TextView textViewType;
    private TextView textViewPrice;
    private TextView textViewPagination;
    private TextView textViewTitle;
    private TextView textViewAddress;
    private TextView textViewDescription;
    private TextView textViewTypeValue;
    private TextView textViewContractTypeValue;
    private TextView textViewSurfaceValue;
    private TextView textViewBuildSurfaceValue;
    private TextView textViewRoomValue;
    private TextView textViewBathValue;
    private TextView textViewParkingValue;
    private TextView textViewPoolValue;
    private TextView textViewGrillValue;
    private TextView textViewPetsValue;
    private TextView textViewPriceValue;
    private TextView textViewAddedOnValue;
    private TextView textViewSurfaceIcon;
    private TextView textViewBathsIcon;
    private TextView textViewRoomsIcon;
    private TextView textViewParkingIcon;

    private ImageView imageViewContact;
    private ImageView imageViewTypeLogo;
    private TextView textViewContactName;
    private Button buttonEmail;
    private Button buttonCall;
    private Drawable favoriteOn;
    private Drawable favoriteOff;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_estate_view);
        //Views
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        textViewPagination = (TextView) findViewById(R.id.textViewPagerIndicator);
        textViewType = (TextView) findViewById(R.id.textViewType);
        textViewPrice = (TextView) findViewById(R.id.textViewPrice);
        textViewTitle = (TextView) findViewById(R.id.textViewTitle);
        textViewAddress = (TextView) findViewById(R.id.textViewAddress);
        textViewDescription = (TextView) findViewById(R.id.textViewDescription);
        textViewTypeValue = (TextView) findViewById(R.id.textViewTypeValue);
        textViewContractTypeValue = (TextView) findViewById(R.id.textViewContractTypeValue);
        textViewSurfaceValue = (TextView) findViewById(R.id.textViewSurfaceValue);
        textViewBuildSurfaceValue = (TextView) findViewById(R.id.textViewBuildSurfaceValue);
        textViewRoomValue = (TextView) findViewById(R.id.textViewRoomValue);
        textViewBathValue = (TextView) findViewById(R.id.textViewBathValue);
        textViewParkingValue = (TextView) findViewById(R.id.textViewParkingValue);
        textViewPoolValue = (TextView) findViewById(R.id.textViewPoolValue);
        textViewGrillValue = (TextView) findViewById(R.id.textViewGrillValue);
        textViewPetsValue = (TextView) findViewById(R.id.textViewPetsValue);
        textViewPriceValue = (TextView) findViewById(R.id.textViewPriceValue);
        textViewAddedOnValue = (TextView) findViewById(R.id.textViewAddedOnValue);
        textViewSurfaceIcon = (TextView) findViewById(R.id.textViewSurfaceIcon);
        textViewRoomsIcon = (TextView) findViewById(R.id.textViewRoomsIcon);
        textViewBathsIcon = (TextView) findViewById(R.id.textViewBathsIcon);
        textViewParkingIcon = (TextView) findViewById(R.id.textViewParkingIcon);

        imageViewContact = (ImageView) findViewById(R.id.imageViewContact);
        imageViewTypeLogo = (ImageView) findViewById(R.id.imageViewTypeLogo);
        textViewContactName = (TextView) findViewById(R.id.textViewContactName);
        buttonCall = (Button) findViewById(R.id.buttonCall);
        buttonEmail = (Button) findViewById(R.id.buttonEmail);
        buttonEmail.setOnClickListener(this);
        buttonCall.setOnClickListener(this);

        Resources res = getResources();
        favoriteOn = res.getDrawable(R.mipmap.ic_heart_white_selected);
        favoriteOff = res.getDrawable(R.mipmap.ic_heart_white);
        favoriteOn = TintHelper.tint(favoriteOn, res.getColor(R.color.accent));
        favoriteOff = TintHelper.tint(favoriteOff,res.getColor(R.color.accent));

        // basic configuration of Toolbar
        getSupportActionBar().setTitle(R.string.details);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        String estateId = getIntent().getExtras().getString(ID_FLAG);

        estate = EstateController.getLocalEstateById(this,estateId);


        String idContact = estate.getContact().getObjectId();
        Contact contact = ContactController.getLocalContactById(this,idContact);
        if(contact.getFirstName()==null){
            contactController = new ContactController(getApplicationContext(),this);
            contactController.getContact(contact.getObjectId());
        }else{
            onGetContactComplete(contact);
        }

        int contractResource;
        //set Data
        switch (estate.getContractType()){
            case Estate.TYPE_CONTRACT_ALQUILER:
                contractResource = R.string.rental;
                break;
            case Estate.TYPE_CONTRACT_RENTA:
                contractResource = R.string.income;
                break;
            default:
                contractResource = R.string.sell;
                break;
        }
        textViewType.setText(contractResource);
        String price;
        if(estate.getCurrency()==1){
            price = "Bs."+estate.getPrice();
        }else{
            price = "USD."+estate.getPrice();
        }
        textViewPrice.setText(price);
        textViewTitle.setText(estate.getTitle());
        textViewAddress.setText(estate.getAddress1());
        textViewDescription.setText(estate.getEstateDescription());

        int typeResource;
        int logoDrawable;
        switch (estate.getType()) {
            case Estate.TYPE_CASA:
                typeResource = R.string.house;
                logoDrawable = R.mipmap.ic_casa;
                break;
            case Estate.TYPE_DEPTO:
                typeResource = R.string.depto;
                logoDrawable = R.mipmap.ic_hotel;
                break;
            case Estate.TYPE_HOTEL:
                typeResource = R.string.hotel;
                logoDrawable = R.mipmap.ic_hotel;
                break;
            case Estate.TYPE_LOCAL:
                typeResource = R.string.local;
                logoDrawable = R.mipmap.ic_local;
                break;
            case Estate.TYPE_LOTE:
                typeResource = R.string.terrain;
                logoDrawable = R.mipmap.ic_terreno;
                break;
            default:
                typeResource = R.string.office;
                logoDrawable = R.mipmap.ic_oficina;
                break;

        }
        Drawable drawableType = getResources().getDrawable(logoDrawable);
        drawableType = TintHelper.tint(drawableType,getResources().getColor(R.color.accent));
        imageViewTypeLogo.setImageDrawable(drawableType);
        textViewTypeValue.setText(typeResource);
        textViewContractTypeValue.setText(contractResource);
        textViewSurfaceValue.setText(estate.getSurface()+".00m2");
        textViewBuildSurfaceValue.setText(estate.getBuiltSurface()+".00m2");
        textViewRoomValue.setText(estate.getBedrooms()+"");
        textViewBathValue.setText(estate.getBathrooms()+"");
        textViewParkingValue.setText(estate.getParkingSpace()+"");
        int poolResource = estate.getPool()?R.string.yes:R.string.no;
        textViewPoolValue.setText(poolResource);
        int bbqResource = estate.getBbq()?R.string.yes:R.string.no;
        textViewGrillValue.setText(bbqResource);
        int petsResource = estate.getPets()?R.string.yes:R.string.no;
        textViewPetsValue.setText(petsResource);
        textViewPriceValue.setText(price);
        textViewAddedOnValue.setText(DateHelper.getShortDate(estate.getCreatedAt()));

        textViewSurfaceIcon.setText(estate.getSurface()+".00m2");
        textViewBathsIcon.setText(estate.getBathrooms()+"");
        textViewRoomsIcon.setText(estate.getBedrooms()+"");
        textViewParkingIcon.setText(estate.getParkingSpace()+"");

        final List<Photo> photoList = EstateController.getLocalPhotosEstateById(this, estateId);
        if(photoList!=null){
            textViewPagination.setText("1/"+photoList.size());
            ViewPager pager = (ViewPager) findViewById(R.id.viewPagerImages);
            ImageAdapter imageAdapter = new ImageAdapter(photoList);
            pager.setAdapter(imageAdapter);
            pager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {

                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

                }

                @Override
                public void onPageSelected(int position) {
                    position++;
                    textViewPagination.setText(position+"/"+photoList.size());
                }

                @Override
                public void onPageScrollStateChanged(int state) {

                }
            });
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_estate_view, menu);

        favoriteButton = menu.findItem(R.id.action_favorite);
        if(estate.getFavorite()){
            favoriteButton.setIcon(favoriteOn);
        }else{
            favoriteButton.setIcon(favoriteOff);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        switch (id) {
            case R.id.action_favorite:
            if(estate.getFavorite()){
                estate.setFavorite(false);
                favoriteButton.setIcon(favoriteOff);
            }else{
                estate.setFavorite(true);
                favoriteButton.setIcon(favoriteOn);
            }
            EstateController.updateEstate(this,estate);
            return true;
            case android.R.id.home:
            if(!estate.getFavorite()){
                Intent intent = new Intent();
                setResult(RESULT_OK, intent);
            }
                finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onGetContactComplete(Contact contact) {
            estate.setContact(contact);
            textViewContactName.setText(contact.getFirstName()+" "+contact.getLastName());
            buttonEmail.setVisibility(View.VISIBLE);
            buttonCall.setVisibility(View.VISIBLE);
            buttonEmail.setText(contact.getEmail());
            buttonCall.setText(contact.getMobile()+"");
            if(contact.getPhoto()!=null){
                ImageLoader.getInstance().DisplayImageCroped(contact.getPhoto().getUrl(), imageViewContact);
            }
    }

    @Override
    public void onGetContactFailed() {

    }

    @Override
    public void internetConnectionError() {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.buttonCall:
                String uri = "tel:" + estate.getContact().getMobile()+"".trim() ;
                Intent callIntent = new Intent(Intent.ACTION_DIAL);
                callIntent.setData(Uri.parse(uri));
                callIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(callIntent);
                break;
            case R.id.buttonEmail:
                Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts(
                        "mailto",estate.getContact().getEmail(), null));
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, "EXTRA_SUBJECT");
                startActivity(Intent.createChooser(emailIntent, "Send email..."));
                break;
        }
    }
}
