package danmunoz.inmobile.ui;

import android.content.Intent;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import danmunoz.inmobile.R;
import danmunoz.inmobile.persistence.PreferencesHelper;

public class IntroActivity extends AppCompatActivity implements View.OnClickListener{
    private ViewPager viewPager;
    private ImageView imageViewFront;
    private ImageView imageViewBack;
    private Button buttonLogin;
    private ViewGroup viewGroupBottomIndicators;
    private int lastPage = 0;
    private int[] imageViewsIntros;
    private int[] titles;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_intro);


        imageViewsIntros = new int[] {
                R.drawable.intro_0,
                R.drawable.intro_1,
                R.drawable.intro_2,
                R.drawable.intro_3,
        };

        titles = new int[] {
                R.string.intro_title_1,
                R.string.intro_title_2,
                R.string.intro_title_3,
                R.string.intro_title_4,
        };

        viewPager = (ViewPager)findViewById(R.id.intro_view_pager);
        imageViewFront = (ImageView)findViewById(R.id.imageViewFront);
        imageViewBack = (ImageView)findViewById(R.id.imageViewBack);
        viewGroupBottomIndicators = (ViewGroup)findViewById(R.id.bottom_pages);
        buttonLogin = (Button) findViewById(R.id.buttonLogin);

        buttonLogin.setOnClickListener(this);

        imageViewBack.setVisibility(View.GONE);
        viewPager.setAdapter(new IntroAdapter());
        viewPager.setPageMargin(0);
        viewPager.setOffscreenPageLimit(1);
        viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int i) {
            }

            @Override
            public void onPageScrollStateChanged(int i) {
                if (i == ViewPager.SCROLL_STATE_IDLE || i == ViewPager.SCROLL_STATE_SETTLING) {
                    if (lastPage != viewPager.getCurrentItem()) {
                        lastPage = viewPager.getCurrentItem();

                        final ImageView fadeoutImage;
                        final ImageView fadeinImage;
                        if (imageViewFront.getVisibility() == View.VISIBLE) {
                            fadeoutImage = imageViewFront;
                            fadeinImage = imageViewBack;

                        } else {
                            fadeoutImage = imageViewBack;
                            fadeinImage = imageViewFront;
                        }

                        fadeinImage.bringToFront();
                        fadeinImage.setImageResource(imageViewsIntros[lastPage]);
                        fadeinImage.clearAnimation();
                        fadeoutImage.clearAnimation();


                        Animation outAnimation = AnimationUtils.loadAnimation(IntroActivity.this, R.anim.icon_anim_fade_out);
                        outAnimation.setAnimationListener(new Animation.AnimationListener() {
                            @Override
                            public void onAnimationStart(Animation animation) {
                            }

                            @Override
                            public void onAnimationEnd(Animation animation) {
                                fadeoutImage.setVisibility(View.GONE);
                            }

                            @Override
                            public void onAnimationRepeat(Animation animation) {

                            }
                        });

                        Animation inAnimation = AnimationUtils.loadAnimation(IntroActivity.this, R.anim.icon_anim_fade_in);
                        inAnimation.setAnimationListener(new Animation.AnimationListener() {
                            @Override
                            public void onAnimationStart(Animation animation) {
                                fadeinImage.setVisibility(View.VISIBLE);
                            }

                            @Override
                            public void onAnimationEnd(Animation animation) {
                            }

                            @Override
                            public void onAnimationRepeat(Animation animation) {

                            }
                        });
                        fadeoutImage.startAnimation(outAnimation);
                        fadeinImage.startAnimation(inAnimation);
                    }
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.buttonLogin:
                if(!PreferencesHelper.getBoolean(PreferencesHelper.INTRO,this)){
                    PreferencesHelper.putBoolean(PreferencesHelper.INTRO,true,this);
                    Intent intent = new Intent(this,MainActivity.class);
                    startActivity(intent);
                }
                finish();
                break;
        }
    }

    private class IntroAdapter extends PagerAdapter {
        @Override
        public int getCount() {
            return 4;
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            View view = View.inflate(container.getContext(), R.layout.intro_view_layout, null);
            TextView headerTextView = (TextView)view.findViewById(R.id.header_text);
            container.addView(view, 0);
            headerTextView.setText(getString(titles[position]));

            return view;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((View) object);
        }

        @Override
        public void setPrimaryItem(ViewGroup container, int position, Object object) {
            super.setPrimaryItem(container, position, object);
            int count = viewGroupBottomIndicators.getChildCount();
            for (int a = 0; a < count; a++) {
                View child = viewGroupBottomIndicators.getChildAt(a);
                if (a == position) {
                    child.setBackgroundColor(getResources().getColor(R.color.primary));
                } else {
                    child.setBackgroundColor(getResources().getColor(R.color.grey_background));
                }
            }
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view.equals(object);
        }

        @Override
        public void finishUpdate(View arg0) {
        }

        @Override
        public void restoreState(Parcelable arg0, ClassLoader arg1) {
        }

        @Override
        public Parcelable saveState() {
            return null;
        }

        @Override
        public void startUpdate(View arg0) {
        }
    }
}