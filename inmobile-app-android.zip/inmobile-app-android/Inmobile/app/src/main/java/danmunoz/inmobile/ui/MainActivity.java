package danmunoz.inmobile.ui;

import android.content.Intent;
import android.content.res.Configuration;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.widget.DrawerLayout;
import android.os.Bundle;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;

import danmunoz.inmobile.R;
import danmunoz.inmobile.persistence.PreferencesHelper;
import danmunoz.inmobile.ui.fragment.AboutFragment;
import danmunoz.inmobile.ui.fragment.ListModeFragment;
import danmunoz.inmobile.ui.fragment.MapModeFragment;
import danmunoz.inmobile.ui.fragment.NavigationDrawerFragment;

/**
 * Created by Vinicius on 4/11/15.
 */
public class MainActivity extends AppCompatActivity implements NavigationDrawerFragment.NavigationDrawerCallbacks{

    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle drawerToggle;
    private int CURRENT_FRAGMENT=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(!PreferencesHelper.getBoolean(PreferencesHelper.INTRO,this)){
            Intent intent = new Intent(this,IntroActivity.class);
            startActivity(intent);
            finish();
            return;
        }
        setContentView(R.layout.activity_main);
        // As we're using a Toolbar, we should retrieve it and set it
        // to be our ActionBar
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        // basic configuration of Toolbar
        getSupportActionBar().setTitle(R.string.map);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        drawerLayout = (DrawerLayout) findViewById(R.id.my_drawer_layout);
        drawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.app_name, R.string.app_name);

        drawerLayout.setDrawerListener(drawerToggle);



        onNavigationDrawerItemSelected(NavigationDrawerFragment.MAP, getString(R.string.map));
        CURRENT_FRAGMENT = NavigationDrawerFragment.MAP;
        changeFrameContent(new MapModeFragment());

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (drawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        drawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        drawerToggle.onConfigurationChanged(newConfig);
    }

    @Override
    public void onBackPressed() {
        if(drawerLayout.isDrawerOpen(Gravity.START)){
            drawerLayout.closeDrawer(Gravity.START);
        }else {
            super.onBackPressed();
        }
    }

    @Override
    public void onNavigationDrawerItemSelected(int position,String title) {
        drawerLayout.closeDrawer(Gravity.START);
        if(position!=CURRENT_FRAGMENT) {
            switch (position) {
                case NavigationDrawerFragment.MAP:
                    getSupportActionBar().setTitle(title);
                    CURRENT_FRAGMENT = NavigationDrawerFragment.MAP;
                    changeFrameContent(new MapModeFragment());
                    break;
                case NavigationDrawerFragment.LIST:
                    getSupportActionBar().setTitle(title);
                    CURRENT_FRAGMENT = NavigationDrawerFragment.LIST;
                    ListModeFragment listModeFragment = new ListModeFragment();
                    Bundle args = new Bundle();
                    args.putBoolean(ListModeFragment.FAVORITES_TAG, false);
                    listModeFragment.setArguments(args);
                    changeFrameContent(listModeFragment);
                    break;
                case NavigationDrawerFragment.FAVORITES:
                    getSupportActionBar().setTitle(title);
                    CURRENT_FRAGMENT = NavigationDrawerFragment.FAVORITES;
                    ListModeFragment listModeFragmentFav = new ListModeFragment();
                    Bundle argsFav = new Bundle();
                    argsFav.putBoolean(ListModeFragment.FAVORITES_TAG, true);
                    listModeFragmentFav.setArguments(argsFav);
                    changeFrameContent(listModeFragmentFav);
                    break;
                case NavigationDrawerFragment.HELP:
                    Intent intent = new Intent(this,IntroActivity.class);
                    startActivity(intent);
                    break;
                case NavigationDrawerFragment.ABOUT:
                    getSupportActionBar().setTitle(title);
                    CURRENT_FRAGMENT = NavigationDrawerFragment.ABOUT;
                    changeFrameContent(new AboutFragment());
                    break;
            }
        }
    }

    public void changeFrameContent(Fragment fragment){
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.content_frame, fragment).commit();
    }
}
