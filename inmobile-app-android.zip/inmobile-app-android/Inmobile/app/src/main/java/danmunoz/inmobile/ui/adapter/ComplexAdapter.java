package danmunoz.inmobile.ui.adapter;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

import danmunoz.inmobile.R;
import danmunoz.inmobile.model.Estate;
import danmunoz.inmobile.model.Type;
import danmunoz.inmobile.util.IntentHelper;
import danmunoz.inmobile.util.imagecache.ImageLoader;

/**
 * Created by Vinicius on 4/20/15.
 */
public class ComplexAdapter extends PagerAdapter {


    private List<Estate> estateList;
    private Context context;

    public ComplexAdapter(List<Estate> estateList, Context context){
        this.estateList = estateList;
        this.context = context;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {

        LinearLayout view = (LinearLayout) View.inflate(container.getContext(), R.layout.layout_info_content, null);
        container.addView(view, 0);

        final Estate estate = estateList.get(position);
        ImageView imageView = (ImageView) view.findViewById(R.id.imageViewInfoContent);
        ImageLoader.getInstance().DisplayImage(estate.getThumbnail().getUrl(),imageView);
        TextView textViewTypeInfo = (TextView) view.findViewById(R.id.textViewTypeInfo);
        TextView textViewTitleInfo = (TextView) view.findViewById(R.id.textViewTitleInfo);
        TextView textViewPriceInfo = (TextView) view.findViewById(R.id.textViewPriceInfo);
        TextView textViewSurface = (TextView) view.findViewById(R.id.textViewSurfaceInfo);
        TextView textViewRoomsInfo = (TextView) view.findViewById(R.id.textViewRoomsInfo);
        TextView textViewBathInfo = (TextView) view.findViewById(R.id.textViewBathInfo);
        int typeResource;
        switch (estate.getType()) {
            case Type.TYPE_CASA:
                typeResource = R.string.house;
                break;
            case Type.TYPE_DEPTO:
                typeResource = R.string.depto;
                break;
            case Type.TYPE_HOTEL:
                typeResource = R.string.hotel;
                break;
            case Type.TYPE_LOCAL:
                typeResource = R.string.local;
                break;
            case Type.TYPE_LOTE:
                typeResource = R.string.terrain;
                break;
            default:
                typeResource = R.string.office;
                break;
        }
        textViewTypeInfo.setText(typeResource);
        textViewTitleInfo.setText(estate.getTitle());
        String price;
        if(estate.getCurrency()==1){
            price = "Bs."+estate.getPrice();
        }else{
            price = "USD."+estate.getPrice();
        }
        textViewPriceInfo.setText(price);
        textViewSurface.setText(estate.getSurface()+".00m2");
        textViewRoomsInfo.setText(estate.getBedrooms()+"");
        textViewBathInfo.setText(estate.getBathrooms()+"");
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                IntentHelper.startEstateDetailIntent(context,estate.getObjectId());
            }
        });

        return view;
    }

    @Override
    public int getCount() {
        return estateList.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view.equals(object);
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }
}
