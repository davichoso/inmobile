package danmunoz.inmobile.ui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import danmunoz.inmobile.R;
import danmunoz.inmobile.model.DrawerItem;

/**
 * Created by Vinicius on 4/11/15.
 */
public class DrawerAdapter extends ArrayAdapter<DrawerItem> {

    // Layout resource that contains drawerItem layout
    private static final int layoutResource = R.layout.row_drawer;

    /**
     * Constructor
     * @param context Application context
     */
    public DrawerAdapter(Context context) {
        super(context,layoutResource );
    }

    /**
     * This method returns the view showing the data
     * @return
     */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) getContext()
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(layoutResource, null);
        }
        TextView textView = (TextView) convertView.findViewById(R.id.textViewDrawerItem);
        ImageView imageView = (ImageView) convertView.findViewById(R.id.imageViewDrawerIcon);
        DrawerItem drawerItem = getItem(position);
        imageView.setImageDrawable(drawerItem.getDrawableIcon());
        textView.setText(drawerItem.getTitle());

        return convertView;
    }
}

