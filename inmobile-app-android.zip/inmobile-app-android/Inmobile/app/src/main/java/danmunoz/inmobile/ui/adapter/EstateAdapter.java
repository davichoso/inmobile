package danmunoz.inmobile.ui.adapter;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import danmunoz.inmobile.R;
import danmunoz.inmobile.controller.EstateController;
import danmunoz.inmobile.model.Estate;
import danmunoz.inmobile.util.IntentHelper;
import danmunoz.inmobile.util.TintHelper;
import danmunoz.inmobile.util.imagecache.ImageLoader;

/**
 * Created by Vinicius on 4/13/15.
 */
public class EstateAdapter extends RecyclerView.Adapter<EstateAdapter.ViewHolderEstate>{

    private List<Estate> estateList;
    private Fragment fragment;
    private boolean favorite;
    private int clickedPosition;
    private Drawable favoriteOn;
    private Drawable favoriteOff;

    public EstateAdapter(List<Estate> estates, Fragment fragment, boolean favorite){
        this.estateList = estates;
        this.fragment = fragment;
        this.favorite = favorite;
        Resources res = fragment.getActivity().getResources();
        favoriteOn = res.getDrawable(R.mipmap.ic_heart_white_selected);
        favoriteOff = res.getDrawable(R.mipmap.ic_heart_white);
        favoriteOn = TintHelper.tint(favoriteOn, res.getColor(R.color.accent));
        favoriteOff = TintHelper.tint(favoriteOff,res.getColor(R.color.accent));
    }

    @Override
    public ViewHolderEstate onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_item, parent, false);
        ViewHolderEstate viewHolderEstate = new ViewHolderEstate(v);
        return viewHolderEstate;
    }

    @Override
    public void onBindViewHolder(final ViewHolderEstate holder, final int position) {
        final Estate estate = estateList.get(position);
        if(estate.getThumbnail()!=null) {
            ImageLoader.getInstance().DisplayImage(estate.getThumbnail().getUrl(), holder.imageViewThumbnail);
        }

        holder.textViewRoomCounter.setText(estate.getBedrooms() + "");
        holder.textViewBatCounter.setText(estate.getBathrooms()+"");
        holder.imageViewThumbnail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickedPosition = position;
                IntentHelper.startEstateDetailIntent(fragment,estate.getObjectId());
            }
        });
        if(estate.getFavorite()){
            holder.imageViewFavorite.setImageDrawable(favoriteOn);
        }else{
            holder.imageViewFavorite.setImageDrawable(favoriteOff);
        }

        String price = estate.getPrice()+"";
        if(estate.getCurrency()==1){
            price = "Bs."+price;
        }else{
            price = "USD."+price;
        }
        holder.textViewPrice.setText(price);

        String address = estate.getAddress1();
        if(address.length()>=22){
          address = address.substring(0,22);
        }
        holder.textViewAddress.setText(address);

        holder.textViewSurface.setText(estate.getSurface()+".00 m2");

        holder.imageViewFavorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(favorite){
                    estate.setFavorite(false);
                    EstateController.updateEstate(fragment.getActivity(), estate);
                    if(estateList.size()==1){
                        removeAt(0);
                    }else {
                        removeAt(position);
                    }
                }else {
                    if (estate.getFavorite()) {
                        ((ImageView) v).setImageDrawable(favoriteOff);
                        estate.setFavorite(false);
                        EstateController.updateEstate(fragment.getActivity(), estate);

                    } else {
                        ((ImageView) v).setImageDrawable(favoriteOn);
                        estate.setFavorite(true);
                        EstateController.updateEstate(fragment.getActivity(), estate);
                    }
                }
            }
        });
    }

    public void addItems(List<Estate> estates){
        estateList.addAll(estates);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return estateList.size();
    }

    public static class ViewHolderEstate extends RecyclerView.ViewHolder {
        // each data item is just a string in this case

        public ImageView imageViewThumbnail;
        public ImageView imageViewFavorite;
        public TextView textViewRoomCounter;
        public TextView textViewBatCounter;
        public TextView textViewSurface;
        public TextView textViewPrice;
        public TextView textViewAddress;

        public ViewHolderEstate(View v) {
            super(v);
            imageViewThumbnail = (ImageView) v.findViewById(R.id.imageViewThumbnail);
            imageViewFavorite = (ImageView) v.findViewById(R.id.imageViewHeart);
            textViewBatCounter = (TextView) v.findViewById(R.id.textViewBatCounter);
            textViewRoomCounter = (TextView) v.findViewById(R.id.textViewRoomCounter);
            textViewPrice = (TextView) v.findViewById(R.id.textViewPrice);
            textViewSurface = (TextView) v.findViewById(R.id.textViewSurface);
            textViewAddress = (TextView) v.findViewById(R.id.textViewAddress);

            imageViewFavorite.setClickable(true);
            imageViewThumbnail.setClickable(true);
        }
    }

    public void removeAt(int position) {
        estateList.remove(position);
        notifyItemRangeChanged(position, estateList.size());
        notifyItemRemoved(position);
    }

    public void update(){
        if(favorite) {
            removeAt(clickedPosition);
        }
    }

}
