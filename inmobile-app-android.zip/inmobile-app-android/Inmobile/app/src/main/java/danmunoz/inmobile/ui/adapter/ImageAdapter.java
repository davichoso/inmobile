package danmunoz.inmobile.ui.adapter;

import android.support.v4.view.PagerAdapter;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.util.List;

import danmunoz.inmobile.R;
import danmunoz.inmobile.model.Photo;
import danmunoz.inmobile.util.imagecache.ImageLoader;

/**
 * Created by Vinicius on 4/17/15.
 */
public class ImageAdapter extends PagerAdapter {
    private List<Photo> photoList;

    public ImageAdapter(List<Photo> photoList){
        this.photoList = photoList;
    }

    @Override
    public int getCount() {
        return photoList.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view.equals(object);
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        ImageView view = (ImageView) View.inflate(container.getContext(), R.layout.image_layout, null);
        container.addView(view, 0);
        ImageLoader.getInstance().DisplayImage(photoList.get(position).getUrl(),view);
        return view;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }
}
