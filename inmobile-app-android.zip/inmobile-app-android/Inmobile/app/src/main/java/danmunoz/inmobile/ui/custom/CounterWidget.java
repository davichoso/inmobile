package danmunoz.inmobile.ui.custom;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import danmunoz.inmobile.R;

/**
 * Created by Vinicius on 4/09/15.
 */
public class CounterWidget extends LinearLayout implements View.OnClickListener{

    private ImageView buttonAdd;
    private ImageView buttonRemove;
    private TextView textViewNumber;
    private int number=0;
    private CounterWidgetListener listener;
    private int minValue = 0;
    private int maxValue = 0;
    private int incrementValue = 0;

    public CounterWidget(Context context) {
        this(context, null, 0, 0);
    }

    public CounterWidget(Context context, AttributeSet attrs) {
        this(context, attrs, 0, 0);
    }

    public CounterWidget(Context context, AttributeSet attrs, int defStyleAttr) {
        this(context, attrs, defStyleAttr, 0);
    }

    public CounterWidget(Context context, AttributeSet attrs, int defStyleAttr,
                         int defStyleRes) {
        super(context, attrs, defStyleAttr);
    }

    public void setListener(CounterWidgetListener listener) {
        this.listener = listener;
    }

    public void setCount(int number){
        this.number = number;
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        buttonAdd = (ImageView) findViewById(R.id.buttonAdd);
        buttonRemove = (ImageView) findViewById(R.id.buttonRemove);
        textViewNumber = (TextView) findViewById(R.id.editTextNumber);
        buttonAdd.setOnClickListener(this);
        buttonRemove.setOnClickListener(this);
        if(number>0){
            textViewNumber.setText(number + "");
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.buttonAdd:
                number+=incrementValue;
                if(listener!=null){
                    listener.onValueChangeListener(number);
                }
                break;
            case R.id.buttonRemove:
                if(number>0) {
                    number-=incrementValue;
                    if(listener!=null) {
                        listener.onValueChangeListener(number);
                    }
                }
                break;
        }
        setValue();
    }

    private void setValue(){
        textViewNumber.setText(number + "");
    }

    public interface CounterWidgetListener{
        void onValueChangeListener(int value);
    }

    public void setType1Min(){
        minValue = 1000;
        incrementValue = 1000;
        maxValue = 99000;
        number = 0;
        setValue();
    }

    public void setType1Max(){
        minValue = 10000;
        incrementValue = 10000;
        maxValue = 990000;
        number = 10000;
        setValue();
    }

    public void setType2Min(){
        minValue = 100;
        incrementValue = 100;
        maxValue = 9900;
        number = 0;
        setValue();
    }

    public void setType2Max(){
        minValue = 500;
        incrementValue = 500;
        maxValue = 19500;
        number = 500;
        setValue();
    }

    public int getNumber() {
        return number;
    }
}
