package danmunoz.inmobile.ui.custom;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.Checkable;
import android.widget.FrameLayout;
import android.widget.ImageView;

import java.util.logging.Filter;

import danmunoz.inmobile.R;

/**
 * Created by Vinicius on 5/13/15.
 */
public class FilterIcon extends FrameLayout implements Checkable {

    private OnCheckedChangeListener listener;

    private static final int[] CHECKED_STATE_SET = {
            android.R.attr.state_checked
    };

    private boolean isChecked;

    public void setListener(OnCheckedChangeListener listener){
        this.listener = listener;
    }

    public FilterIcon(Context context) {
        this(context, null, 0, 0);
    }

    public FilterIcon(Context context, AttributeSet attrs) {
        this(context, attrs, 0, 0);
    }

    public FilterIcon(Context context, AttributeSet attrs, int defStyleAttr) {
        this(context, attrs, defStyleAttr, 0);
    }

    public FilterIcon(Context context, AttributeSet attrs, int defStyleAttr,
                                int defStyleRes) {
        super(context, attrs, defStyleAttr);

        setClickable(true);
    }

    @Override
    public boolean isChecked() {
        return isChecked;
    }

    @Override
    public boolean performClick() {
        toggle();
        return super.performClick();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        // As we have changed size, we should invalidate the outline so that is the the
        // correct size

    }

    @Override
    public void setChecked(boolean checked) {
        if (checked == isChecked) {
            return;
        }
        isChecked = checked;

        // Now refresh the drawable state (so the icon changes)
        refreshDrawableState();
        if (listener != null) {
            listener.onCheckedChanged(this, checked);
        }
    }

    @Override
    public void toggle() {
        setChecked(!isChecked);
    }

    @Override
    protected int[] onCreateDrawableState(int extraSpace) {
        final int[] drawableState = super.onCreateDrawableState(extraSpace + 1);
        if (isChecked()) {
            mergeDrawableStates(drawableState, CHECKED_STATE_SET);
        }
        return drawableState;
    }

    public interface OnCheckedChangeListener {
        void onCheckedChanged(FilterIcon filterIcon, boolean isChecked);
    }
}
