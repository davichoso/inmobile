package danmunoz.inmobile.ui.custom;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.littlefluffytoys.littlefluffylocationlibrary.LocationInfo;

import danmunoz.inmobile.R;
import danmunoz.inmobile.model.Estate;

/**
 * Created by Vinicius on 5/15/15.
 */
public class FilterLayout extends LinearLayout implements FilterIcon.OnCheckedChangeListener{

    private FilterIcon casa;
    private FilterIcon depa;
    private FilterIcon terreno;
    private FilterIcon local;
    private FilterIcon oficina;
    private FilterIcon hotel;
    private FilterIcon venta;
    private FilterIcon alquiler;
    private FilterIcon anticretico;

    private TextView textViewDialogTypeTitle;
    private TextView textViewDialogTypeContractTitle;

    private TextView textViewMin;
    private TextView textViewMax;
    private CounterWidget counterWidgetMin;
    private CounterWidget counterWidgetMax;

    private boolean typeMode1;
    private boolean typeMode2;
    private boolean isEnable;


    public FilterLayout(Context context) {
        this(context, null, 0, 0);
    }

    public FilterLayout(Context context, AttributeSet attrs) {
        this(context, attrs, 0, 0);
    }

    public FilterLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        this(context, attrs, defStyleAttr, 0);
    }

    public FilterLayout(Context context, AttributeSet attrs, int defStyleAttr,
                         int defStyleRes) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        casa = (FilterIcon) findViewById(R.id.filterCasa);
        depa = (FilterIcon) findViewById(R.id.filterDepa);
        terreno = (FilterIcon) findViewById(R.id.filterTerreno);
        local = (FilterIcon) findViewById(R.id.filterLocal);
        oficina = (FilterIcon) findViewById(R.id.filterOficina);
        hotel = (FilterIcon) findViewById(R.id.filterHotel);
        venta = (FilterIcon) findViewById(R.id.filterVenta);
        alquiler = (FilterIcon) findViewById(R.id.filterAlquiler);
        anticretico = (FilterIcon) findViewById(R.id.filterAnti);
        casa.setListener(this);
        depa.setListener(this);
        terreno.setListener(this);
        local.setListener(this);
        oficina.setListener(this);
        hotel.setListener(this);
        venta.setListener(this);
        alquiler.setListener(this);
        anticretico.setListener(this);
        textViewDialogTypeTitle = (TextView) findViewById(R.id.textViewDialogTypeTitle);
        textViewDialogTypeContractTitle = (TextView) findViewById(R.id.textViewDialogTypeContractTitle);
        textViewDialogTypeTitle.setText(R.string.type);
        textViewDialogTypeContractTitle.setText(R.string.type_contract);

        textViewMin = (TextView) findViewById(R.id.textViewMin);
        textViewMax = (TextView) findViewById(R.id.textViewMax);
        counterWidgetMin = (CounterWidget) findViewById(R.id.counterMin);
        counterWidgetMax = (CounterWidget) findViewById(R.id.counterMax);
    }

    private void disableMinMax(){
        isEnable = false;
        textViewMin.setVisibility(View.GONE);
        textViewMax.setVisibility(View.GONE);
        counterWidgetMin.setVisibility(View.GONE);
        counterWidgetMax.setVisibility(View.GONE);
    }

    private void enableMinMax(){
        isEnable = true;
        textViewMin.setVisibility(View.VISIBLE);
        textViewMax.setVisibility(View.VISIBLE);
        counterWidgetMin.setVisibility(View.VISIBLE);
        counterWidgetMax.setVisibility(View.VISIBLE);
    }

    public String getFilter(){
        boolean haveOne=false;
        String filterType = "\"type\":{\"$in\":[";

        if(casa.isChecked()){
            filterType+= Estate.TYPE_CASA;
            haveOne=true;
        }
        if(depa.isChecked()){
            if(haveOne){
                filterType+=",";
            }
            haveOne=true;
            filterType+= Estate.TYPE_DEPTO;
        }
        if(terreno.isChecked()){
            if(haveOne){
                filterType+=",";
            }
            haveOne=true;
            filterType+= Estate.TYPE_LOTE;
        }
        if(local.isChecked()){
            if(haveOne){
                filterType+=",";
            }
            haveOne=true;
            filterType+= Estate.TYPE_LOCAL;
        }
        if(oficina.isChecked()){
            if(haveOne){
                filterType+=",";
            }
            haveOne=true;
            filterType+= Estate.TYPE_OFICINA;
        }
        if(hotel.isChecked()){
            if(haveOne){
                filterType+=",";
            }
            haveOne=true;
            filterType+= Estate.TYPE_HOTEL;
        }
        if(haveOne){
            filterType+="]}";
        }else{
            filterType = null;
        }
        LocationInfo locationInfo = new LocationInfo(getContext());
        String locationFilter= "\"coordinate\":{\"$nearSphere\":{\"__type\":\"GeoPoint\",\"longitude\":"+locationInfo.lastLong+",\"latitude\":"+locationInfo.lastLat+"}}";
        if(isEnable){
            if(filterType!=null) {
                filterType += ","+locationFilter+",\"price\":{\"$gte\":";
            }else{

                filterType =locationFilter+",\"price\":{\"$gte\":";
            }
            filterType+= counterWidgetMin.getNumber() + ",\"$lte\":" + counterWidgetMax.getNumber() + "}";
        }
        return filterType;
    }

    @Override
    public void onCheckedChanged(FilterIcon filterIcon, boolean isChecked) {

        typeMode1 = false;
        typeMode2 = false;
        if(venta.isChecked()){
            typeMode1 = true;
            typeMode2 = false;
        }
        if(alquiler.isChecked()){
            typeMode1 = false;
            if(!venta.isChecked()) {
                typeMode2 = true;
            }
        }
        if(anticretico.isChecked()){
            typeMode2 = false;
            if(!typeMode1 && !alquiler.isChecked()){
                typeMode1=true;
            }
        }
        if(!typeMode1){
            if(venta.isChecked()&&anticretico.isChecked()&&!alquiler.isChecked()){
                typeMode1=true;
            }
        }
        if (typeMode1){
            enableMinMax();
            counterWidgetMin.setType1Min();
            counterWidgetMax.setType1Max();
        }else{
            if(typeMode2){
                enableMinMax();
                counterWidgetMin.setType2Min();
                counterWidgetMax.setType2Max();
            }else {
                disableMinMax();
            }
        }
    }
}
