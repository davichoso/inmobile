package danmunoz.inmobile.ui.dialog;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatDialog;
import android.view.View;
import android.widget.Button;

import danmunoz.inmobile.R;
import danmunoz.inmobile.ui.custom.FilterLayout;

/**
 * Created by Vinicius on 5/10/15.
 */
public class DialogFilter extends AppCompatDialog implements View.OnClickListener {

    protected Button buttonSelect;
    protected Button buttonCancel;
    private FilterListener filterListener;
    private FilterLayout filterLayout;

    public DialogFilter(Context context, FilterListener filterListener) {
        super(context,R.style.MyDialogTheme);
        this.filterListener = filterListener;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_base_select);
        buttonSelect = (Button) findViewById(R.id.buttonDialogSelect);
        buttonCancel = (Button) findViewById(R.id.buttonDialogCancel);
        filterLayout = (FilterLayout) findViewById(R.id.filterLayout);
        buttonSelect.setOnClickListener(this);
        buttonCancel.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.buttonDialogSelect:
                filterListener.onFilterSelect(filterLayout.getFilter());
                dismiss();
                break;
            case R.id.buttonDialogCancel:
                dismiss();
                break;
        }
    }

    // Container Activity must implement this interface
    public interface FilterListener {
        void onFilterSelect(String filter);
    }
}
