package danmunoz.inmobile.ui.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

import danmunoz.inmobile.R;
import danmunoz.inmobile.controller.EstateController;
import danmunoz.inmobile.controller.listener.EstateListener;
import danmunoz.inmobile.model.Estate;
import danmunoz.inmobile.ui.adapter.EstateAdapter;

/**
 * Created by Vinicius on 4/12/15.
 */
public class ListModeFragment extends Fragment implements EstateListener{

    final public static String FAVORITES_TAG="favorites";
    private RecyclerView recyclerViewProducts;
    private EstateAdapter adapterProduct;
    private LinearLayoutManager layoutManager;
    private EstateController estateController;
    private boolean favorites;
    private CardView loadingView;

    private boolean loading = true;
    int pastVisiblesItems, visibleItemCount, totalItemCount;
    private SwipeRefreshLayout swipeRefreshLayout;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_list, container, false);

        favorites = getArguments().getBoolean(FAVORITES_TAG);
        loadingView = (CardView) rootView.findViewById(R.id.viewLoading);
        estateController = new EstateController(getActivity(),this);
        recyclerViewProducts = (RecyclerView) rootView.findViewById(R.id.recycler_view_estate_list);
        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        recyclerViewProducts.setHasFixedSize(true);

        // use a linear layout manager
        layoutManager = new LinearLayoutManager(getActivity());

        recyclerViewProducts.setLayoutManager(layoutManager);


        swipeRefreshLayout = (SwipeRefreshLayout) rootView.findViewById(R.id.swipe_list);
        swipeRefreshLayout.setColorSchemeResources(R.color.accent, R.color.primary);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if(!favorites) {
                    estateController.getEstateList(null, 0, 0, false);
                }else{
                    swipeRefreshLayout.setRefreshing(false);
                }
            }
        });

        if(favorites){
            swipeRefreshLayout.setEnabled(false);
            estateController.getFavoriteList();
        }else {
            estateController.getEstateList(null,0,0,false);
            showLoading();
        }

        return rootView;

    }

    @Override
    public void onGetEstateListComplete(List<Estate> estateList) {
        hideLoading();
        swipeRefreshLayout.setRefreshing(false);
        adapterProduct = new EstateAdapter(estateList,this,favorites);
        recyclerViewProducts.setAdapter(adapterProduct);
        recyclerViewProducts.setOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {

                visibleItemCount = layoutManager.getChildCount();
                totalItemCount = layoutManager.getItemCount();
                pastVisiblesItems = layoutManager.findFirstVisibleItemPosition();

                if (loading) {
                    if ((visibleItemCount + pastVisiblesItems) >= totalItemCount && !swipeRefreshLayout.isRefreshing()
                            && !favorites) {
                        loading = false;
                        estateController.getEstateList(null, 0, 0, false, adapterProduct.getItemCount());
                        showLoading();
                    }
                }
            }
        });
        loading = true;
    }

    @Override
    public void onGetEstateListCompleteSkipped(List<Estate> estateList) {
        hideLoading();
        if(!estateList.isEmpty()) {
            adapterProduct.addItems(estateList);
            if(estateList.size()>=10) {
                loading = true;
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode==getActivity().RESULT_OK){
            adapterProduct.update();
        }
    }

    @Override
    public void onGetEstateListFailed() {
        hideLoading();
    }

    @Override
    public void internetConnectionError() {
        hideLoading();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_map, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    public void showLoading(){
        swipeRefreshLayout.setEnabled(false);
        loadingView.setVisibility(View.VISIBLE);
    }

    public void hideLoading(){
        swipeRefreshLayout.setEnabled(true);
        loadingView.setVisibility(View.INVISIBLE);
    }
}
