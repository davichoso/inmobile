package danmunoz.inmobile.ui.fragment;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.CardView;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.littlefluffytoys.littlefluffylocationlibrary.LocationInfo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import danmunoz.inmobile.R;
import danmunoz.inmobile.controller.EstateController;
import danmunoz.inmobile.controller.listener.EstateListener;
import danmunoz.inmobile.model.ComplexMarker;
import danmunoz.inmobile.model.Estate;
import danmunoz.inmobile.model.Type;
import danmunoz.inmobile.ui.adapter.ComplexAdapter;
import danmunoz.inmobile.ui.dialog.DialogFilter;
import danmunoz.inmobile.util.PriceHelper;

/**
 * Created by Vinicius on 4/12/15.
 */
public class MapModeFragment extends Fragment implements EstateListener, GoogleMap.OnMarkerClickListener,GoogleMap.OnMapClickListener,GoogleMap.OnCameraChangeListener, DialogFilter.FilterListener {

    private GoogleMap googlemap;
    private EstateController estateController;
    private List<ComplexMarker> complexMarkers;
    private View markerView;
    private ImageView parent;
    private ImageView icon;
    private TextView numTxt;
    private ViewPager pager;
    private LinearLayout infoContent;
    private TextView pagerIndicator;
    private String filterJson = null;
    private CardView loadingView;
    private final int zoom = 14;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_map, container, false);

        pager = (ViewPager) rootView.findViewById(R.id.viewPagerEstates);
        pagerIndicator = (TextView) rootView.findViewById(R.id.textViewPagerIndicator);
        infoContent = (LinearLayout) rootView.findViewById(R.id.infoContentLayout);
        loadingView = (CardView) rootView.findViewById(R.id.viewLoading);
        MapsInitializer.initialize(getActivity());
        estateController = new EstateController(getActivity(),this);
        switch (GooglePlayServicesUtil.isGooglePlayServicesAvailable(getActivity()) )
        {
            case ConnectionResult.SUCCESS:

                android.support.v4.app.FragmentManager myFM = getChildFragmentManager();
                final SupportMapFragment myMAPF = (SupportMapFragment) myFM.findFragmentById(R.id.map);
                googlemap = myMAPF.getMap();
                googlemap.setMyLocationEnabled(true);
                googlemap.getUiSettings().setZoomControlsEnabled(true);
                final View mapView = myFM
                        .findFragmentById(R.id.map).getView();
                if (mapView.getViewTreeObserver().isAlive()) {
                    mapView.getViewTreeObserver().addOnGlobalLayoutListener(
                            new ViewTreeObserver.OnGlobalLayoutListener() {

                                @Override
                                public void onGlobalLayout() {
                                    // TODO Auto-generated method stub
                                    mapView.getViewTreeObserver()
                                            .removeGlobalOnLayoutListener(this);
                                    googlemap.setOnMarkerClickListener(MapModeFragment.this);
                                    googlemap.setOnMapClickListener(MapModeFragment.this);
                                    LocationInfo locationInfo = new LocationInfo(getActivity());
                                    //estateController.getEstateList(null, locationInfo.lastLat, locationInfo.lastLong, true);
                                    googlemap.moveCamera(CameraUpdateFactory.newLatLngZoom(
                                            new LatLng(locationInfo.lastLat, locationInfo.lastLong), zoom));
                                    googlemap.setOnCameraChangeListener(MapModeFragment.this);
                                    showLoading();
                                }
                            });
                }
                break;
            case ConnectionResult.SERVICE_MISSING:
                // Todo install google play services
                break;
            case ConnectionResult.SERVICE_VERSION_UPDATE_REQUIRED:
                // Todo go to playstore to upload google play services
                break;
            default:
                // Todo some error happends try again later
        }

        return rootView;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public void onGetEstateListComplete(List<Estate> estateList) {
        hideLoading();
        googlemap.clear();
        if(complexMarkers!=null) {
            complexMarkers.clear();
        }
        if(MapModeFragment.this.isVisible()) {
            this.complexMarkers = new ArrayList<>();
            for (Estate estate : estateList) {
                if (markerView == null) {
                    markerView = ((LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.custom_marker_layout, null);
                }
                ComplexMarker result = verifyEstate(estate);
                if(result!=null){
                    result.addEstate(estate);
                }
                else{
                    result = new ComplexMarker(null);
                    parent = (ImageView) markerView.findViewById(R.id.imageViewParent);
                    icon = (ImageView) markerView.findViewById(R.id.imageViewIcon);
                    numTxt = (TextView) markerView.findViewById(R.id.num_txt);
                    switch (estate.getType()) {
                        case Type.TYPE_CASA:
                            parent.setImageResource(R.drawable.casa_bg);
                            icon.setImageResource(R.drawable.casa_icon);
                            break;
                        case Type.TYPE_DEPTO:
                            parent.setImageResource(R.drawable.depa_bg);
                            icon.setImageResource(R.drawable.depa_icon);
                            break;
                        case Type.TYPE_HOTEL:
                            parent.setImageResource(R.drawable.hotel_bg);
                            icon.setImageResource(R.drawable.hotel_icon);
                            break;
                        case Type.TYPE_LOCAL:
                            parent.setImageResource(R.drawable.local_bg);
                            icon.setImageResource(R.drawable.local_icon);
                            break;
                        case Type.TYPE_LOTE:
                            parent.setImageResource(R.drawable.lote_bg);
                            icon.setImageResource(R.drawable.lote_icon);
                            break;
                        case Type.TYPE_OFICINA:
                            parent.setImageResource(R.drawable.oficina_bg);
                            icon.setImageResource(R.drawable.oficina_icon);
                            break;

                    }
                    if(result.getComplexId()==null) {
                        numTxt.setText(PriceHelper.getPricePin(estate.getPrice()));
                    }else{
                        numTxt.setText(result.getEstateList().size()+" x");
                    }

                    result.marker = googlemap.addMarker(new MarkerOptions()
                                    .position(new LatLng(estate.getLatitude(), estate.getLongitude()))
                                    .icon(BitmapDescriptorFactory.fromBitmap(createDrawableFromView(getActivity(), markerView)))
                    );
                    result.addEstate(estate);
                    this.complexMarkers.add(result);
                }
            }
        }
    }

    @Override
    public void onGetEstateListCompleteSkipped(List<Estate> estateList) {
        //Nothing to do here
    }

    @Override
    public void onGetEstateListFailed() {
        hideLoading();
    }

    @Override
    public void internetConnectionError() {
        hideLoading();
    }

    public BitmapDescriptor getBitmap(int drawable) {

        return BitmapDescriptorFactory.fromResource(drawable);
    }

    // Convert a view to bitmap
    public static Bitmap createDrawableFromView(Context context, View view) {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((Activity) context).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        view.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        view.measure(displayMetrics.widthPixels, displayMetrics.heightPixels);
        view.layout(0, 0, displayMetrics.widthPixels, displayMetrics.heightPixels);
        view.buildDrawingCache();
        Bitmap bitmap = Bitmap.createBitmap(view.getMeasuredWidth(), view.getMeasuredHeight(), Bitmap.Config.ARGB_8888);

        Canvas canvas = new Canvas(bitmap);
        view.draw(canvas);

        return bitmap;
    }

    public ComplexMarker getMarker(Marker x) {
        Iterator<ComplexMarker> _it = complexMarkers.iterator();
        ComplexMarker temp;
        while (_it.hasNext()) {
            temp = _it.next();
            if (temp.marker.equals(x)) {
                return temp;
            }
        }

        return null;
    }

    public ComplexMarker verifyEstate(Estate estate) {
        if(estate.getComplexEstate()==null){
            return null;
        }
        Iterator<ComplexMarker> _it = complexMarkers.iterator();
        ComplexMarker temp;
        while (_it.hasNext()) {
            temp = _it.next();
            if (temp.getComplexId()!=null && temp.getComplexId().equals(estate.getComplexEstate().getObjectId())) {
                return temp;
            }
        }
        return null;
    }

    @Override
    public boolean onMarkerClick(Marker marker) {
        ComplexMarker complexMarker = getMarker(marker);
        infoContent.setVisibility(View.VISIBLE);
        final ComplexAdapter complexAdapter = new ComplexAdapter(complexMarker.getEstateList(),getActivity());
        pager.setAdapter(complexAdapter);
        pagerIndicator.setText("1/" + complexAdapter.getCount());
        pager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {

            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                position++;
                pagerIndicator.setText(position + "/" + complexAdapter.getCount());
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        googlemap.moveCamera(CameraUpdateFactory.newLatLngZoom(
                marker.getPosition(), googlemap.getCameraPosition().zoom));

        return true;
    }

    @Override
    public void onMapClick(LatLng latLng) {
        infoContent.setVisibility(View.INVISIBLE);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_map, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    private DialogFilter dialog;

    @Override
    public boolean onOptionsItemSelected(MenuItem menu) {
        switch (menu.getItemId()){
            case R.id.action_filter:
                if(dialog==null){
                    dialog = new DialogFilter(getActivity(),MapModeFragment.this);
                }
                dialog.show();
                return true;
            default:
                return super.onOptionsItemSelected(menu);
        }
    }

    private Timer timer;

    @Override
    public void onCameraChange(CameraPosition cameraPosition) {
        if(timer!=null){
            timer.cancel();
        }
        timer = new Timer(3000,1000,googlemap.getCameraPosition().target);
        timer.start();
    }

    @Override
    public void onFilterSelect(String filter) {
        infoContent.setVisibility(View.INVISIBLE);
        LatLng location = googlemap.getCameraPosition().target;
        this.filterJson = filter;
        estateController.getEstateList(filter, location.latitude, location.longitude, true);
        showLoading();
    }

    public void showLoading(){
        loadingView.setVisibility(View.VISIBLE);
    }

    public void hideLoading(){
        loadingView.setVisibility(View.INVISIBLE);
    }


    public class Timer  extends CountDownTimer {
        private LatLng position;
        public Timer(long millisInFuture, long countDownInterval,LatLng position) {
            super(millisInFuture, countDownInterval);
            this.position = position;
            // TODO Auto-generated constructor stub
        }

        @Override
        public void onFinish() {
            // TODO Auto-generated method stub
            estateController.getEstateList(filterJson,position.latitude,position.longitude,true);
        }

        @Override
        public void onTick(long millisUntilFinished) {
            // TODO Auto-generated method stub

        }
    }
}
