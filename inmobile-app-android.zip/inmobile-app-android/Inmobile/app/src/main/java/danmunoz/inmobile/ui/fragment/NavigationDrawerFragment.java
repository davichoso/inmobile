package danmunoz.inmobile.ui.fragment;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;

import danmunoz.inmobile.R;
import danmunoz.inmobile.model.DrawerItem;
import danmunoz.inmobile.ui.adapter.DrawerAdapter;
import danmunoz.inmobile.util.TintHelper;

/**
 * Created by Vinicius on 4/11/15.
 */
public class NavigationDrawerFragment extends Fragment{



    public static final int MAP = 0;
    public static final int LIST = 1;
    public static final int FAVORITES = 2;
    public static final int COLLECTIONS = 3;
    public static final int HELP = 4;
    public static final int ABOUT = 5;


    // ListView with the menu items
    private ListView drawerListView;

    // Adapter of drawerItem
    private DrawerAdapter drawerAdapter;

    private int lastSelected;

    /**
     * A pointer to the current callbacks instance (the Activity).
     */
    private NavigationDrawerCallbacks navigationDrawerCallbacks;

    @Override
    public View onCreateView(LayoutInflater inflater,ViewGroup container, Bundle savedInstanceState) {

        LinearLayout view = (LinearLayout) inflater.inflate(
                R.layout.fragment_navigation_drawer, container, false);

        drawerListView = (ListView) view.findViewById(R.id.list_view_drawer);
        drawerAdapter = new DrawerAdapter(getActivity());

        // set the data to the listView
        Resources resources = getActivity().getResources();
        ColorStateList stateList = resources.getColorStateList(R.color.tint_selector);

        Drawable drawable = resources.getDrawable(R.mipmap.ic_map);
        drawable = DrawableCompat.wrap(drawable);
        DrawableCompat.setTintList(drawable, stateList);
        drawerAdapter.add(new DrawerItem(getString(R.string.map),drawable));
        drawable = resources.getDrawable(R.mipmap.ic_list);
        drawable = TintHelper.tint(drawable,stateList);
        drawerAdapter.add(new DrawerItem(getString(R.string.list), drawable));
        drawable = resources.getDrawable(R.mipmap.ic_heart_selected);
        drawable = TintHelper.tint(drawable,stateList);
        drawerAdapter.add(new DrawerItem(getString(R.string.favorites), drawable));
        drawable = resources.getDrawable(R.mipmap.ic_star);
        drawable = TintHelper.tint(drawable,stateList);
        drawerAdapter.add(new DrawerItem(getString(R.string.rate_us), drawable));
        drawable = resources.getDrawable(R.mipmap.ic_help);
        drawable = TintHelper.tint(drawable,stateList);
        drawerAdapter.add(new DrawerItem(getString(R.string.help), drawable));
        drawable = resources.getDrawable(R.mipmap.ic_about);
        drawable = TintHelper.tint(drawable,stateList);
        drawerAdapter.add(new DrawerItem(getString(R.string.about), drawable));
        drawerListView.setAdapter(drawerAdapter);
        drawerListView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

        // Set the first item of the list checked in this case Diary
        drawerListView.setItemChecked(MAP, true);
        lastSelected = 0;

        drawerListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String title = drawerAdapter.getItem(position).getTitle();
                navigationDrawerCallbacks.onNavigationDrawerItemSelected(position,title);
                if(position<=FAVORITES || position == ABOUT) {
                    lastSelected = position;
                }else{
                    drawerListView.setItemChecked(lastSelected, true);
                }
            }
        });
        return view;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            this.navigationDrawerCallbacks = (NavigationDrawerCallbacks)activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement navigationDrawerCallbacks");
        }
    }

    public interface NavigationDrawerCallbacks {
        /**
         * Called when an item in the navigation drawer is selected.
         */
        void onNavigationDrawerItemSelected(int position,String title);
    }
}
