package danmunoz.inmobile.util;

/**
 * Created by Vinicius on 4/18/15.
 */
public class DateHelper {

    public static String getShortDate(String date){
        String year = date.substring(0,4);
        String month = date.substring(5,7);
        String day = date.substring(8,10);
        return day+"/"+month+"/"+year;
    }
}
