package danmunoz.inmobile.util;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.Fragment;

import danmunoz.inmobile.model.Estate;
import danmunoz.inmobile.ui.EstateViewActivity;

/**
 * Created by Vinicius on 4/17/15.
 */
public class IntentHelper {

    public static void startEstateDetailIntent(Context context, String estateId){
        Intent startCommentsView = new Intent(context, EstateViewActivity.class);
        startCommentsView.putExtra(EstateViewActivity.ID_FLAG, estateId);
        context.startActivity(startCommentsView);
    }

    public static void startEstateDetailIntent(Fragment fragment, String estateId){
        Intent startCommentsView = new Intent(fragment.getActivity(), EstateViewActivity.class);
        startCommentsView.putExtra(EstateViewActivity.ID_FLAG, estateId);
        fragment.startActivityForResult(startCommentsView, EstateViewActivity.FRAGMENT_RESULT);
    }
}
