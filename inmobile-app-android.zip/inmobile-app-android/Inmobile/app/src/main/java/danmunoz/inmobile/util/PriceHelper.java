package danmunoz.inmobile.util;

/**
 * Created by Vinicius on 4/15/15.
 */
public class PriceHelper {

    public static String getPricePin(int price){
        if(price>=1000){
            return (price/1000)+"K";
        }else{
            return price+"";
        }
    }

}
