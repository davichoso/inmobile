package danmunoz.inmobile.util;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.support.v4.graphics.drawable.DrawableCompat;

/**
 * Created by Vinicius on 5/24/15.
 */
public class TintHelper {

    public static Drawable tint(Drawable drawable,int colorResource){
        drawable = DrawableCompat.wrap(drawable);
        DrawableCompat.setTint(drawable,colorResource);
        DrawableCompat.setTintMode(drawable, PorterDuff.Mode.SRC_IN);
        return drawable;
    }

    public static Drawable tint(Drawable drawable,ColorStateList stateList){
        drawable = DrawableCompat.wrap(drawable);
        DrawableCompat.setTintList(drawable, stateList);
        DrawableCompat.setTintMode(drawable, PorterDuff.Mode.SRC_IN);
        return drawable;
    }


}
